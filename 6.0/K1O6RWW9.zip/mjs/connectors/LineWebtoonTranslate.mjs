import Connector from '../engine/Connector.mjs';

/**
 *
 */
export default class LineWebtoonTranslate extends Connector {

    /**
     *
     */
    constructor() {
        super();
        super.id = 'linewebtoon-translate';
        super.label = 'Line Webtoon (Translate)';
        this.tags = [];
        this.url = 'https://translate.webtoons.com';
    }

    _getMangaList( callback ) {
        callback( new Error( 'Please report this broken website on HakuNeko\'s GitHub project page.' ), undefined );
    }
    _getChapterList( manga, callback ) {
        callback( new Error( 'Please report this broken website on HakuNeko\'s GitHub project page.' ), undefined );
    }
    _getPageList( manga, chapter, callback ) {
        callback( new Error( 'Please report this broken website on HakuNeko\'s GitHub project page.' ), undefined );
    }
}