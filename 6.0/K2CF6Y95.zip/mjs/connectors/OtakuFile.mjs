import WordPressEManga from './templates/WordPressEManga.mjs';

/**
 *
 */
export default class OtakuFile extends WordPressEManga {

    /**
     *
     */
    constructor() {
        super();
        // Public members for usage in UI (mandatory)
        super.id = 'otakufile';
        super.label = 'OtakuFile';
        this.tags = [ 'manga', 'indonesian' ];
        // Private members for internal usage only (convenience)
        this.url = 'https://otakufile.com';
        this.path = '/daftar-komik/';

        this.queryMangas = 'div#wrap div#content ul div.anilist-diatur li a.zeebuy';
        this.queryChapters = 'div.epl ul li span.t1 a';
        this.queryPages = 'div#wrap source[src]:not([src=""])';
    }
}