export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '9af36a',
        link: 'https://github.com/manga-download/hakuneko/commits/9af36a023124cfc10eb0b12457e3e1dd44ce211e',
    }
};