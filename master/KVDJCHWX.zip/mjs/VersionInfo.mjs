export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '7f0571',
        link: 'https://github.com/manga-download/hakuneko/commits/7f057129563a5e42cc2cfb3461d00df9e534b328',
    }
};