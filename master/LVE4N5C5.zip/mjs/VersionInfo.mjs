export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '38ae6a',
        link: 'https://github.com/manga-download/hakuneko/commits/38ae6ac6588feb42928073d5ea68b76741b55029',
    }
};