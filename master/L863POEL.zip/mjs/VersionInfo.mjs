export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ba3c9c',
        link: 'https://github.com/manga-download/hakuneko/commits/ba3c9cb862e7e19b8e8ea128108b3ba622362978',
    }
};