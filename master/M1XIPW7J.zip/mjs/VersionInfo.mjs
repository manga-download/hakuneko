export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a0c0cd',
        link: 'https://github.com/manga-download/hakuneko/commits/a0c0cd83c12b9fe233e5f3fdcecc4ecd346707ef',
    }
};