export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ade3e2',
        link: 'https://github.com/manga-download/hakuneko/commits/ade3e27a51e220a52d2c6984a34c81fe93cd426b',
    }
};