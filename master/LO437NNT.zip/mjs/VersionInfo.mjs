export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'c5440d',
        link: 'https://github.com/manga-download/hakuneko/commits/c5440db400a04da4a2385214de6a68a303116053',
    }
};