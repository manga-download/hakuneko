export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '79769b',
        link: 'https://github.com/manga-download/hakuneko/commits/79769b821696105494291f17b74bb627be1eade3',
    }
};