export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a277a8',
        link: 'https://github.com/manga-download/hakuneko/commits/a277a8a200614ae1b870163b11a94abd27fd08c9',
    }
};