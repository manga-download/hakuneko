export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ec4234',
        link: 'https://github.com/manga-download/hakuneko/commits/ec42340d119c8a68c85a67e985d5b695767eb79f',
    }
};