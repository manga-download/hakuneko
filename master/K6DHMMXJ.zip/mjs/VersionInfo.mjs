export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '350cc9',
        link: 'https://github.com/manga-download/hakuneko/commits/350cc94164091f61f4a805e065ad25008ed0942c',
    }
};