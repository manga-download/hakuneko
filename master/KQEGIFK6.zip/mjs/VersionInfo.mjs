export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '02cb80',
        link: 'https://github.com/manga-download/hakuneko/commits/02cb801812036111a7f4efd3a143e128b0e3a052',
    }
};