export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '10321f',
        link: 'https://github.com/manga-download/hakuneko/commits/10321f6c623361f01d1ed1264514e11d66d1acea',
    }
};