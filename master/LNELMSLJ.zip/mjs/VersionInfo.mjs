export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '08918c',
        link: 'https://github.com/manga-download/hakuneko/commits/08918cfc2bb86c98fc37785666f0bfddd723566b',
    }
};