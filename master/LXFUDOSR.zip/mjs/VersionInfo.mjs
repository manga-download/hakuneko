export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '8a9bcd',
        link: 'https://github.com/manga-download/hakuneko/commits/8a9bcd62b4238371150266aab86cf71932904b06',
    }
};