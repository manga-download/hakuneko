export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3ee319',
        link: 'https://github.com/manga-download/hakuneko/commits/3ee31917c257397ddfa243d7128477b637b7bfcc',
    }
};