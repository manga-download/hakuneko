export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '771b06',
        link: 'https://github.com/manga-download/hakuneko/commits/771b06f0cf01c01a861a6312ffe1ec2ca543090c',
    }
};