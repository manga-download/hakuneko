export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ee56a2',
        link: 'https://github.com/manga-download/hakuneko/commits/ee56a2159723d73294069178610a71109bde1cbf',
    }
};