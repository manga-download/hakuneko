export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '528ba4',
        link: 'https://github.com/manga-download/hakuneko/commits/528ba43dadad219f93318997a8402dd10c83c41a',
    }
};