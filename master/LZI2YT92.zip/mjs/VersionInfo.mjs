export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '534da7',
        link: 'https://github.com/manga-download/hakuneko/commits/534da7f2595f830d24bd2dd8831f45a5a376cc2e',
    }
};