export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '2d6116',
        link: 'https://github.com/manga-download/hakuneko/commits/2d6116b40142e562a3621cc0a163266e480a6cc1',
    }
};