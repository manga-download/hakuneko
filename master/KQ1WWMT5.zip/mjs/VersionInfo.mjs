export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '181536',
        link: 'https://github.com/manga-download/hakuneko/commits/1815368cf7ed7abc57a86099a07c6d93d586419e',
    }
};