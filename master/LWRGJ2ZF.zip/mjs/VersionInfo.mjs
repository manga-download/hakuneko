export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '25af70',
        link: 'https://github.com/manga-download/hakuneko/commits/25af70bd59de25951b8c787e4edbfd38adce9fc7',
    }
};