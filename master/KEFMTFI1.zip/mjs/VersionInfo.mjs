export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '37823f',
        link: 'https://github.com/manga-download/hakuneko/commits/37823f1d5357d200c8c46c49be60d373134a1c7b',
    }
};