export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '9cc6f1',
        link: 'https://github.com/manga-download/hakuneko/commits/9cc6f121c4fd03647ea5f11af0933df8f8553567',
    }
};