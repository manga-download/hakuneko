export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '512058',
        link: 'https://github.com/manga-download/hakuneko/commits/512058c32b16ddee42c1321ebd157a8c3b7b6a41',
    }
};