export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '15b8ab',
        link: 'https://github.com/manga-download/hakuneko/commits/15b8ab881fb384196c16d1b47d78d613f25dcfa5',
    }
};