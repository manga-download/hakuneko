export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4b7407',
        link: 'https://github.com/manga-download/hakuneko/commits/4b7407205fa60160559c8104d1caeab707ad6f6e',
    }
};