export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b42e6b',
        link: 'https://github.com/manga-download/hakuneko/commits/b42e6bf23fbd00fb13986325c8f03ac61bfcfa4f',
    }
};