export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '0e30b2',
        link: 'https://github.com/manga-download/hakuneko/commits/0e30b28d68a008b699470ace14dc566404d63cfb',
    }
};