export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5512b3',
        link: 'https://github.com/manga-download/hakuneko/commits/5512b3e55ce1482010c5a57659733bd4ca48414c',
    }
};