export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '7be8f4',
        link: 'https://github.com/manga-download/hakuneko/commits/7be8f46c14aaa22a6b61bee24851bd35991fea07',
    }
};