export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3fca8e',
        link: 'https://github.com/manga-download/hakuneko/commits/3fca8eae1bcecdf813c2725c5fffcc6eaab592cb',
    }
};