export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'eec3b4',
        link: 'https://github.com/manga-download/hakuneko/commits/eec3b41e1008f1474b98070a7c0d36c6ae5ba70c',
    }
};