export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'cd0080',
        link: 'https://github.com/manga-download/hakuneko/commits/cd00802560672bb21606038edc6c0dd4ea904951',
    }
};