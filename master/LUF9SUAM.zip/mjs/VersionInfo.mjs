export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '63188f',
        link: 'https://github.com/manga-download/hakuneko/commits/63188f4978602bf9e1b1afeb5a3059e4c977527f',
    }
};