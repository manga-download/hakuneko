export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4f8df4',
        link: 'https://github.com/manga-download/hakuneko/commits/4f8df4e8aad7b4ac86cfdf68c45b910f17a01d2e',
    }
};