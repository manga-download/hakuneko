export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '2895d3',
        link: 'https://github.com/manga-download/hakuneko/commits/2895d3c26f14833573edd0f5623990885dae7d07',
    }
};