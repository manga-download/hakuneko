export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a35ffa',
        link: 'https://github.com/manga-download/hakuneko/commits/a35ffaeaf5fa03468ece4fb673a954c48cd0d7de',
    }
};