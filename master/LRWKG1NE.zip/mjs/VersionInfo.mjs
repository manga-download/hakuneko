export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1efe23',
        link: 'https://github.com/manga-download/hakuneko/commits/1efe233b525af09ec8169c0d7baba01716486112',
    }
};