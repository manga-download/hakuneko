export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'bfbd4f',
        link: 'https://github.com/manga-download/hakuneko/commits/bfbd4fbb9dca2c967643b654a330c2ec754d561e',
    }
};