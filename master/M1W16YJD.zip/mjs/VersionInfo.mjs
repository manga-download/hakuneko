export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e7604d',
        link: 'https://github.com/manga-download/hakuneko/commits/e7604d6368a5732753a61b9bed90bb0904384210',
    }
};