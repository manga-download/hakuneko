export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '7d542a',
        link: 'https://github.com/manga-download/hakuneko/commits/7d542a9b5451f16a9e1278bf8792bcf1ee638ffa',
    }
};