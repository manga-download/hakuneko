export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '2d7887',
        link: 'https://github.com/manga-download/hakuneko/commits/2d78871e9f5efbb6b710403762fca2d158e92330',
    }
};