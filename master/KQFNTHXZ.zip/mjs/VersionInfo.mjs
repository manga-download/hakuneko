export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'bb8303',
        link: 'https://github.com/manga-download/hakuneko/commits/bb83032c70a8be73abdd2c6ee43d9aef0fc82e81',
    }
};