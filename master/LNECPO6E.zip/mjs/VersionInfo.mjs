export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '0ecce3',
        link: 'https://github.com/manga-download/hakuneko/commits/0ecce312a3a82652b8b916021f9cde45a5859b18',
    }
};