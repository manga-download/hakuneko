export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e1097d',
        link: 'https://github.com/manga-download/hakuneko/commits/e1097db72703dcf0b975f34ea4976cf8c98a534f',
    }
};