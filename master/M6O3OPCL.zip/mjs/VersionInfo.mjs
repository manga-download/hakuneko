export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1c436e',
        link: 'https://github.com/manga-download/hakuneko/commits/1c436edab5d397e2e9cb13b666bb6ea7301352ed',
    }
};