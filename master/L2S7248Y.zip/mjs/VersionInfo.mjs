export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '02d943',
        link: 'https://github.com/manga-download/hakuneko/commits/02d94345b754f5823f41b05b6c1835ebefc81f22',
    }
};