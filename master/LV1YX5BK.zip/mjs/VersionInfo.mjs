export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4318aa',
        link: 'https://github.com/manga-download/hakuneko/commits/4318aacf5b2611eba591c8894fde31a5303c6ba0',
    }
};