export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4aeb50',
        link: 'https://github.com/manga-download/hakuneko/commits/4aeb501e79548ad521920678ea141ca4f83e554e',
    }
};