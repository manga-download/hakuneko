export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f83972',
        link: 'https://github.com/manga-download/hakuneko/commits/f83972db1b38a67ec7ec3b628c3f20f6c732513a',
    }
};