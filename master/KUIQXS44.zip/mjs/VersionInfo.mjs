export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a872fe',
        link: 'https://github.com/manga-download/hakuneko/commits/a872fe63eaff3689d51eef169ef1d975e54b6915',
    }
};