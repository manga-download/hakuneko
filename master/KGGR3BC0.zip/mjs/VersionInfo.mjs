export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '2eeac0',
        link: 'https://github.com/manga-download/hakuneko/commits/2eeac01f728dd16ff9c4798b9ccc072d1b692ad0',
    }
};