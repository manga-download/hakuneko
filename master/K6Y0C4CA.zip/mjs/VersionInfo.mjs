export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'fca16e',
        link: 'https://github.com/manga-download/hakuneko/commits/fca16e0c9adcef0632c9faf4130dd9d1b9c3121a',
    }
};