export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5f6436',
        link: 'https://github.com/manga-download/hakuneko/commits/5f643677acc9c367223d7fca323ff1dc985e98ac',
    }
};