export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3519fb',
        link: 'https://github.com/manga-download/hakuneko/commits/3519fbb142676d3dc225e177632411202fa2cc5d',
    }
};