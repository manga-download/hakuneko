export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '80f04a',
        link: 'https://github.com/manga-download/hakuneko/commits/80f04a7158bab1563f0067abb071f5f58e5653d0',
    }
};