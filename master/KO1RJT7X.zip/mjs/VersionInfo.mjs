export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '100d77',
        link: 'https://github.com/manga-download/hakuneko/commits/100d77cba90b5a558166a066cf48123c5619082b',
    }
};