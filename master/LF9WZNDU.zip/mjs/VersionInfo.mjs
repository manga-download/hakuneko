export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '80210c',
        link: 'https://github.com/manga-download/hakuneko/commits/80210c785a925c288ab0b6e0c891cc04eac0ec70',
    }
};