export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5a3ad4',
        link: 'https://github.com/manga-download/hakuneko/commits/5a3ad44e515b8aa9c1ac73a51c5b73ac52e36888',
    }
};