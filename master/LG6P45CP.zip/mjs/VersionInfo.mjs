export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '9884c9',
        link: 'https://github.com/manga-download/hakuneko/commits/9884c994a99fb11e71fb7fca7482d50d1be26ca3',
    }
};