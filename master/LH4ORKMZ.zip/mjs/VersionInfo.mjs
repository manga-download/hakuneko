export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '16bca8',
        link: 'https://github.com/manga-download/hakuneko/commits/16bca848b60520dc36805d4e83610a4fd0d4e104',
    }
};