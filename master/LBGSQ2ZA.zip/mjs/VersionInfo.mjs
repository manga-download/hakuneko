export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '23f590',
        link: 'https://github.com/manga-download/hakuneko/commits/23f590840f113d09d319443ec8ae78d28c48cc98',
    }
};