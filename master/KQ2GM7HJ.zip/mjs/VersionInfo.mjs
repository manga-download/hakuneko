export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '27ff21',
        link: 'https://github.com/manga-download/hakuneko/commits/27ff21d79f63724f66d62b593c528772b1994855',
    }
};