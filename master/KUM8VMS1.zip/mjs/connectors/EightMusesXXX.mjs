import WordPressMadara from './templates/WordPressMadara.mjs';

export default class EightMusesXXX extends WordPressMadara {

    constructor() {
        super();
        super.id = '8musesxxx';
        super.label = '8 MUSES XXX';
        this.tags = [ 'hentai', 'english' ];
        this.url = 'https://8muses.xxx';
    }
}