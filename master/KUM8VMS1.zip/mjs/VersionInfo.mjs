export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '2c1090',
        link: 'https://github.com/manga-download/hakuneko/commits/2c10909e9eea210950efe16bbd33f9eb6b966ee4',
    }
};