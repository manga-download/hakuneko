export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5df9f7',
        link: 'https://github.com/manga-download/hakuneko/commits/5df9f7ac8e422a19c16704c0713c958f586aec0c',
    }
};