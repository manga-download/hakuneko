export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '23a8fb',
        link: 'https://github.com/manga-download/hakuneko/commits/23a8fb1a6806023683bfad08af706e81d743d2de',
    }
};