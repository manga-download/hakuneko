export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '8ec048',
        link: 'https://github.com/manga-download/hakuneko/commits/8ec0486cd3db74782d7a674a529891e369769d05',
    }
};