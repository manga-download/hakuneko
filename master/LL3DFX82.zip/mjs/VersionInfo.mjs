export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a6da6a',
        link: 'https://github.com/manga-download/hakuneko/commits/a6da6a1d20ea595e87d7334c9be134abdac5c73c',
    }
};