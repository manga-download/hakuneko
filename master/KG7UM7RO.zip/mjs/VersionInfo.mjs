export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'd00fed',
        link: 'https://github.com/manga-download/hakuneko/commits/d00fed996f8fe6de13fb27db7be1a30fa302c268',
    }
};