export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4de168',
        link: 'https://github.com/manga-download/hakuneko/commits/4de16810b823af4f2a41524ba8e1d01e664f1f23',
    }
};