export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1155c8',
        link: 'https://github.com/manga-download/hakuneko/commits/1155c88279016a0d6e64132a1e4814f964f6ad39',
    }
};