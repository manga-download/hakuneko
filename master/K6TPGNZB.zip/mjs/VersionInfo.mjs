export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f73f82',
        link: 'https://github.com/manga-download/hakuneko/commits/f73f82b0ff47464e7592fd4500b887e589e99136',
    }
};