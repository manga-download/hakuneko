export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '23d296',
        link: 'https://github.com/manga-download/hakuneko/commits/23d29669be63390563e33f2f2c829bc2c492e1b9',
    }
};