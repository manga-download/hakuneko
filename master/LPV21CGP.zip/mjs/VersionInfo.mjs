export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '0ba380',
        link: 'https://github.com/manga-download/hakuneko/commits/0ba38032f7babbfada0d1e4d35a8f2082f64ecd5',
    }
};