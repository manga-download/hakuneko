export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '51d657',
        link: 'https://github.com/manga-download/hakuneko/commits/51d65790ee974279c95d2b20bfdad28b10f3f2ac',
    }
};