export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'bb9e1b',
        link: 'https://github.com/manga-download/hakuneko/commits/bb9e1b6e5807d416aa74f387a45f901013f2d829',
    }
};