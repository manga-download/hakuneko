export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '6bd44c',
        link: 'https://github.com/manga-download/hakuneko/commits/6bd44cfcb3ccff59c059e159be5025fe7f841840',
    }
};