export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '0fe944',
        link: 'https://github.com/manga-download/hakuneko/commits/0fe944f4fab1d3492825618a0804ad3aee823c62',
    }
};