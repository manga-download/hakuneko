export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '6c2a52',
        link: 'https://github.com/manga-download/hakuneko/commits/6c2a52e50bfd8facefa47e9138bf2a74148d3641',
    }
};