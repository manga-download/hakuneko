export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b216ba',
        link: 'https://github.com/manga-download/hakuneko/commits/b216ba041ae18497c6b7444bc264024aba381a58',
    }
};