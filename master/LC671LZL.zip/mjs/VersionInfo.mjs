export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ce2335',
        link: 'https://github.com/manga-download/hakuneko/commits/ce2335692cc0d159214dffa05bcf32caf36bf55f',
    }
};