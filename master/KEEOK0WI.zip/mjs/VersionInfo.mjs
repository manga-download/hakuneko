export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4d6f45',
        link: 'https://github.com/manga-download/hakuneko/commits/4d6f45f72f26179544cf2caca1c2c901782d59f5',
    }
};