export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1ba925',
        link: 'https://github.com/manga-download/hakuneko/commits/1ba925d0495d4b378e4f9183ab81f227779670ac',
    }
};