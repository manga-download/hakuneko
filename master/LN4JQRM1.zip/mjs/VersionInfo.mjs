export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '715d3c',
        link: 'https://github.com/manga-download/hakuneko/commits/715d3c550bb5a236f5df6d7fb58778363d1df04b',
    }
};