export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'af2b21',
        link: 'https://github.com/manga-download/hakuneko/commits/af2b21f5268fe030214b5b9ac4be4e704831c230',
    }
};