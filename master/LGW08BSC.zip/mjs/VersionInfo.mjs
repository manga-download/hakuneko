export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'c5ad18',
        link: 'https://github.com/manga-download/hakuneko/commits/c5ad18242c1b746b8d8e23f0467d03ef02e25283',
    }
};