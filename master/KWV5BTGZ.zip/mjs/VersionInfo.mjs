export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'cb3457',
        link: 'https://github.com/manga-download/hakuneko/commits/cb3457e83aa4b8863341201812f9626709a3a475',
    }
};