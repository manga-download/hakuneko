export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '93c651',
        link: 'https://github.com/manga-download/hakuneko/commits/93c651bad56151deb4c7fc98e085a250bb1357a9',
    }
};