export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '06a693',
        link: 'https://github.com/manga-download/hakuneko/commits/06a693ad0dc0c908c4d5d3636d154cd9e175e470',
    }
};