export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '203b00',
        link: 'https://github.com/manga-download/hakuneko/commits/203b005d2324b58c16f9d8043eb82e6bedfb1b66',
    }
};