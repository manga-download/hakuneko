export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f005f6',
        link: 'https://github.com/manga-download/hakuneko/commits/f005f6e0b229723751981722c3d2281baf543aee',
    }
};