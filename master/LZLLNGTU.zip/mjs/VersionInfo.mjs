export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '78381c',
        link: 'https://github.com/manga-download/hakuneko/commits/78381c7528fa22d4fdb26c963e555e711d70be90',
    }
};