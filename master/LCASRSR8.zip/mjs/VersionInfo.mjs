export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '7e1228',
        link: 'https://github.com/manga-download/hakuneko/commits/7e122821952a46aff544a623848a1971f51c7fd4',
    }
};