export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b9a2f8',
        link: 'https://github.com/manga-download/hakuneko/commits/b9a2f851059c82cf58e783a564ef0857b20586ab',
    }
};