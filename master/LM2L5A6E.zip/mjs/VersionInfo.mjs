export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e69fc2',
        link: 'https://github.com/manga-download/hakuneko/commits/e69fc219e6a18bba1625936b8ce267bfce6c5c3d',
    }
};