export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '79a3cf',
        link: 'https://github.com/manga-download/hakuneko/commits/79a3cfecacc1a39e9817572e4ae2d47d0992410a',
    }
};