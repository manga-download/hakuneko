export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '8ae2c8',
        link: 'https://github.com/manga-download/hakuneko/commits/8ae2c8762b7a526283f0117d95b0d91d336cd733',
    }
};