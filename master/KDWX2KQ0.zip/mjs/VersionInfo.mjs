export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5d49bd',
        link: 'https://github.com/manga-download/hakuneko/commits/5d49bd400522f9a9e079bed265488cfd660d5056',
    }
};