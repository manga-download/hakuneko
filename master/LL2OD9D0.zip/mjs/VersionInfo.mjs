export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '30ae88',
        link: 'https://github.com/manga-download/hakuneko/commits/30ae8838da995398319df2ae3d621e7692f3d5c9',
    }
};