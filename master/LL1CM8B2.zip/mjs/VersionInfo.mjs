export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '39d193',
        link: 'https://github.com/manga-download/hakuneko/commits/39d1932100893f437e9fbd64288ca12fced76198',
    }
};