export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a37b72',
        link: 'https://github.com/manga-download/hakuneko/commits/a37b7278a0a5cd8e6ec45c19b54e5e10898237f4',
    }
};