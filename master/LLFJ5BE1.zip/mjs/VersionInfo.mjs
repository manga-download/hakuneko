export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '66877d',
        link: 'https://github.com/manga-download/hakuneko/commits/66877d7694cc8d2fc90271610ff2fafbf2d3553e',
    }
};