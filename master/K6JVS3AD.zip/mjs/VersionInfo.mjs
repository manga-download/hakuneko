export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '08e7dd',
        link: 'https://github.com/manga-download/hakuneko/commits/08e7dd86e9274c521421ff097c5ba0e7b1c17979',
    }
};