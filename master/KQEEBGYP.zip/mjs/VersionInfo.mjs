export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e68501',
        link: 'https://github.com/manga-download/hakuneko/commits/e685019131f48cffeb5bf82c8fb2187675b09d03',
    }
};