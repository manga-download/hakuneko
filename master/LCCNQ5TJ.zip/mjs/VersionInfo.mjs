export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '643a39',
        link: 'https://github.com/manga-download/hakuneko/commits/643a39a00209970ccce68bc644eea110ed937826',
    }
};