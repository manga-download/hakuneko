export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '44edf2',
        link: 'https://github.com/manga-download/hakuneko/commits/44edf2f41e8723c5d2dca607378c128575f9f6fe',
    }
};