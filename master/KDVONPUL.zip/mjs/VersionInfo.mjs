export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '8194f8',
        link: 'https://github.com/manga-download/hakuneko/commits/8194f814c8216dbe94c3b294bb8e5e497366e5c1',
    }
};