export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '55c50b',
        link: 'https://github.com/manga-download/hakuneko/commits/55c50b16730c4446cf27ff62f28f361459b772f4',
    }
};