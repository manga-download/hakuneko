export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a5c135',
        link: 'https://github.com/manga-download/hakuneko/commits/a5c135e7121bf26f05fe0b5a89976103b8c83384',
    }
};