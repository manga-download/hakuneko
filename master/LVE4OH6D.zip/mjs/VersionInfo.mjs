export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'de0673',
        link: 'https://github.com/manga-download/hakuneko/commits/de0673ba6ec8181777afddf1a589a1567c7781aa',
    }
};