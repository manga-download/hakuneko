export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1edc02',
        link: 'https://github.com/manga-download/hakuneko/commits/1edc0296c2ac5387220bf1ae6f45c8fd6a11134e',
    }
};