export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'bb28db',
        link: 'https://github.com/manga-download/hakuneko/commits/bb28db9b8fba354190020eb57743a9638eceb775',
    }
};