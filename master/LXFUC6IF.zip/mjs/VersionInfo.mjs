export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '84b016',
        link: 'https://github.com/manga-download/hakuneko/commits/84b016bf52e4148e40aff68d4eaa3e778784493c',
    }
};