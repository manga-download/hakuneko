export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '622a96',
        link: 'https://github.com/manga-download/hakuneko/commits/622a96bdc43456be51a5fd2b93e8fb5ef19d8aba',
    }
};