export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1881bf',
        link: 'https://github.com/manga-download/hakuneko/commits/1881bfef36b45226744e970afe2cf66af7dbf375',
    }
};