export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'c3d003',
        link: 'https://github.com/manga-download/hakuneko/commits/c3d003c5af87e9893f5ac26201e2645157d7efc5',
    }
};