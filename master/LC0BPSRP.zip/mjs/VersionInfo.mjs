export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'd53b10',
        link: 'https://github.com/manga-download/hakuneko/commits/d53b10c2ceb1f550bf84f5001116d87ca8c8b9a6',
    }
};