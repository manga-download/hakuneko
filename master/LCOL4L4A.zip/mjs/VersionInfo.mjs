export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '61aabc',
        link: 'https://github.com/manga-download/hakuneko/commits/61aabc5418de8fef4beb2334ae9e4576fb5ad0b6',
    }
};