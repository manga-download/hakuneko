export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b77538',
        link: 'https://github.com/manga-download/hakuneko/commits/b77538619e63d696cdc2de564fd0d3554f27fc85',
    }
};