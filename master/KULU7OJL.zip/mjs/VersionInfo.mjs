export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '11810a',
        link: 'https://github.com/manga-download/hakuneko/commits/11810a127a1acbbdcd0627f5614f7611d5130946',
    }
};