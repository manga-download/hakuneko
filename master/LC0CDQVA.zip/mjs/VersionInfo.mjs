export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '0a7035',
        link: 'https://github.com/manga-download/hakuneko/commits/0a703505e9fd5c4083bfcd4b6ff6a01f4842ae82',
    }
};