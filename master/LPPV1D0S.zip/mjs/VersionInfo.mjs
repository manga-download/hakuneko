export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'd1163e',
        link: 'https://github.com/manga-download/hakuneko/commits/d1163ebd77862e43b02d01dfab5ce11c8e19ccb5',
    }
};