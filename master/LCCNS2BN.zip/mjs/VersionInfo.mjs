export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '96e553',
        link: 'https://github.com/manga-download/hakuneko/commits/96e553608d390a33193fb497596c887f9778cf2e',
    }
};