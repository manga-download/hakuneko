export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'bafb4e',
        link: 'https://github.com/manga-download/hakuneko/commits/bafb4e1d70d7034f6837b306d44ef25cf85e7f8b',
    }
};