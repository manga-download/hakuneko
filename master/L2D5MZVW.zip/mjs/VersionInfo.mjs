export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '876b3e',
        link: 'https://github.com/manga-download/hakuneko/commits/876b3e23378138f8efc46025f5b90f5b1593a47e',
    }
};