export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '65b311',
        link: 'https://github.com/manga-download/hakuneko/commits/65b311379cf7750550f234d4574d880c145533a4',
    }
};