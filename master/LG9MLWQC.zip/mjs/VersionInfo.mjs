export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'c22fb0',
        link: 'https://github.com/manga-download/hakuneko/commits/c22fb0fe7849a56f11d6f3b295fee24a05ac3c1a',
    }
};