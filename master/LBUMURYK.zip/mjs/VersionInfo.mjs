export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '59f365',
        link: 'https://github.com/manga-download/hakuneko/commits/59f365bda5e0d5fa49a6f47cd9cf63133160a7f6',
    }
};