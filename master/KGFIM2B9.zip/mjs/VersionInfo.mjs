export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '66cb1f',
        link: 'https://github.com/manga-download/hakuneko/commits/66cb1fb0e98e540ed3c4f683d8f953377ffee5f2',
    }
};