export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e71ae9',
        link: 'https://github.com/manga-download/hakuneko/commits/e71ae9a4c27a8e0f3bd7d5c8a06a0e3fffd9bd41',
    }
};