export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3c93d1',
        link: 'https://github.com/manga-download/hakuneko/commits/3c93d1aec113f11e0c0d54814454b201d364f61c',
    }
};