export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '84e089',
        link: 'https://github.com/manga-download/hakuneko/commits/84e089b947925ff0da30bf3972b438b26d3670df',
    }
};