export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '2ec578',
        link: 'https://github.com/manga-download/hakuneko/commits/2ec578141d9f1475c1f337dcd0a3fa592465bbb0',
    }
};