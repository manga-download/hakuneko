export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '0fcc9b',
        link: 'https://github.com/manga-download/hakuneko/commits/0fcc9b245b76751c96ca3095b37db9a928329a02',
    }
};