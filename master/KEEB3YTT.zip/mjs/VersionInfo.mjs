export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a7e891',
        link: 'https://github.com/manga-download/hakuneko/commits/a7e891785dd8199094005c7f06d81718556b0ca3',
    }
};