export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '18b9ad',
        link: 'https://github.com/manga-download/hakuneko/commits/18b9ad6f00b7cdaf34721468eba6f262614dbeb5',
    }
};