export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '48417a',
        link: 'https://github.com/manga-download/hakuneko/commits/48417ae651cede9a94ca58a2b9c531c97f7e4495',
    }
};