export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5724de',
        link: 'https://github.com/manga-download/hakuneko/commits/5724de60693c7bc506a5dd8fd57f19e44614c6b7',
    }
};