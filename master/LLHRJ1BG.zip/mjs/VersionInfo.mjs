export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5043dc',
        link: 'https://github.com/manga-download/hakuneko/commits/5043dc3fbb4e4004749ee3792dd2a4a0d37d1653',
    }
};