export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5a2f3b',
        link: 'https://github.com/manga-download/hakuneko/commits/5a2f3b9de748740171ca120353384405c4539606',
    }
};