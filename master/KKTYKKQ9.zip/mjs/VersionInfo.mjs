export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'aab77f',
        link: 'https://github.com/manga-download/hakuneko/commits/aab77fd1893b7d709f6df3569f008fff9a32dc0c',
    }
};