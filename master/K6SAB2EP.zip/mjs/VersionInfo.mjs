export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '188b58',
        link: 'https://github.com/manga-download/hakuneko/commits/188b58db748ae1e05568536a663407d0cec2f70d',
    }
};