export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '92c22e',
        link: 'https://github.com/manga-download/hakuneko/commits/92c22efeee35d5b4b0ffdb7c869ee86f43a9cc5c',
    }
};