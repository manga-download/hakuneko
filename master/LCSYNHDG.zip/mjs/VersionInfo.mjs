export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'c40a2d',
        link: 'https://github.com/manga-download/hakuneko/commits/c40a2d3ecd33c3f5ac056752b9e0281c62eb2cdc',
    }
};