export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b6cbad',
        link: 'https://github.com/manga-download/hakuneko/commits/b6cbad8b39ac271478e1b5d0197bb7e62135eff4',
    }
};