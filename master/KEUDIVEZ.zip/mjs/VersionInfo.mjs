export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '0b4c55',
        link: 'https://github.com/manga-download/hakuneko/commits/0b4c559fceee42f18d8bf0695949296129d7ba36',
    }
};