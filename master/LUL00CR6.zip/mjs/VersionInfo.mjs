export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '39f99f',
        link: 'https://github.com/manga-download/hakuneko/commits/39f99fdb60a32d71e838d2b1cce6c3baf149eae1',
    }
};