export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e5f928',
        link: 'https://github.com/manga-download/hakuneko/commits/e5f9289bd2d2b54a9ddded347d53fa4385abd81b',
    }
};