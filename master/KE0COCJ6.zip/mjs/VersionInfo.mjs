export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '57a756',
        link: 'https://github.com/manga-download/hakuneko/commits/57a756c2a62c8959aefebda29b470f1d5d9b23ae',
    }
};