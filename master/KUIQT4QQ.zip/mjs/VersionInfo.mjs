export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '7bb0a3',
        link: 'https://github.com/manga-download/hakuneko/commits/7bb0a3d5d07769703ee55dea05d405b5afcfb943',
    }
};