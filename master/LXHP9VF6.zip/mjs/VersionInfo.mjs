export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '8ab309',
        link: 'https://github.com/manga-download/hakuneko/commits/8ab309ccc21e731aaa4cfc09fc5b3211e27b67b5',
    }
};