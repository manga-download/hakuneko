export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '31868b',
        link: 'https://github.com/manga-download/hakuneko/commits/31868b52dc9d5b87bf3695cf6e5ae02be62ffae4',
    }
};