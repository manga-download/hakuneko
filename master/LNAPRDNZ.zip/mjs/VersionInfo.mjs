export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'db5196',
        link: 'https://github.com/manga-download/hakuneko/commits/db51966b9e207fe24b252bc0482279de0dca4a64',
    }
};