export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a4db9b',
        link: 'https://github.com/manga-download/hakuneko/commits/a4db9b23b25ca5dd2696a35b99d398d370375c81',
    }
};