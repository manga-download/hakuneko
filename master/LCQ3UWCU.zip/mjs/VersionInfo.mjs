export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1e5953',
        link: 'https://github.com/manga-download/hakuneko/commits/1e5953e4d189ded736a50d8bf9b96520aa4c3d6b',
    }
};