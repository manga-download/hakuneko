export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f5f794',
        link: 'https://github.com/manga-download/hakuneko/commits/f5f7948fe838fae9ca9c8500e49f78bdaa9a9f23',
    }
};