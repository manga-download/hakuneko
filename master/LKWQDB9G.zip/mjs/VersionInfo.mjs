export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '8a486f',
        link: 'https://github.com/manga-download/hakuneko/commits/8a486f6d93cecc4806d13e796a167ca38c7e9820',
    }
};