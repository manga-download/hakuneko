export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '32c049',
        link: 'https://github.com/manga-download/hakuneko/commits/32c0490d862f1e65247876eb1aa0b973a73977d0',
    }
};