export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e1c0cd',
        link: 'https://github.com/manga-download/hakuneko/commits/e1c0cd21fa33525957664e474496be9d0cc5d759',
    }
};