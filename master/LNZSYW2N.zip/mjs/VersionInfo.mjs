export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '88f146',
        link: 'https://github.com/manga-download/hakuneko/commits/88f146107b308826158a79ecc0552845d97fea1a',
    }
};