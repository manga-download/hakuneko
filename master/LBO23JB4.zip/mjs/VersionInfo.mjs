export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '8fc5d0',
        link: 'https://github.com/manga-download/hakuneko/commits/8fc5d06ee8c038fd414945565d9fb50d6fe4272f',
    }
};