export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a3b2e8',
        link: 'https://github.com/manga-download/hakuneko/commits/a3b2e84204407f681dbffdf53278a08e0750c8a3',
    }
};