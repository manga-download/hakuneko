export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '7171aa',
        link: 'https://github.com/manga-download/hakuneko/commits/7171aa22bf9c944dc2487fc5141df58ea63a9b0a',
    }
};