export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '9ba80f',
        link: 'https://github.com/manga-download/hakuneko/commits/9ba80fe816bbfd0c39952cfabd91ca970de7fe00',
    }
};