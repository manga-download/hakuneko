export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '626c78',
        link: 'https://github.com/manga-download/hakuneko/commits/626c78af8cff467923abb95d8cb71c3d32417bf8',
    }
};