export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '71580f',
        link: 'https://github.com/manga-download/hakuneko/commits/71580feb0ccb0912a0bfe6a09446623e60441393',
    }
};