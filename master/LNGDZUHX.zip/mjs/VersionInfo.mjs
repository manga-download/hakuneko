export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1de6a4',
        link: 'https://github.com/manga-download/hakuneko/commits/1de6a4f3ba8e90547aeebaf204e8d256999d32ca',
    }
};