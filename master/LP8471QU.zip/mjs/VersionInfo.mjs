export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'd4f1e9',
        link: 'https://github.com/manga-download/hakuneko/commits/d4f1e97900c709a9f4862733156e1918f6fab000',
    }
};