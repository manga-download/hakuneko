export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '6d5e58',
        link: 'https://github.com/manga-download/hakuneko/commits/6d5e584039abdedad00805e859b88d214b9ea64b',
    }
};