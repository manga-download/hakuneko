export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '25ddfb',
        link: 'https://github.com/manga-download/hakuneko/commits/25ddfbc0b7411a35b6d546e45f22a66a8f57f652',
    }
};