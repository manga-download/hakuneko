export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '359a38',
        link: 'https://github.com/manga-download/hakuneko/commits/359a3874c12673db630ef3e985c0234001884fd0',
    }
};