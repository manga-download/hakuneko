export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '216631',
        link: 'https://github.com/manga-download/hakuneko/commits/2166313705a9a1a6daf45d88009fa988750e4f49',
    }
};