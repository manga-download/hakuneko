export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '71822c',
        link: 'https://github.com/manga-download/hakuneko/commits/71822cecab81ad249bc21aed539bec75bc91d91a',
    }
};