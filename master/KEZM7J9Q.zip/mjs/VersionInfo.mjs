export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '21f7b1',
        link: 'https://github.com/manga-download/hakuneko/commits/21f7b142c066daac0274c8b7319a3d8ff7f5b1c7',
    }
};