export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f3f08f',
        link: 'https://github.com/manga-download/hakuneko/commits/f3f08fb0ec7bc37ed926ae62f612efef63e5cd28',
    }
};