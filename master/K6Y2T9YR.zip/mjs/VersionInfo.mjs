export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '949d5a',
        link: 'https://github.com/manga-download/hakuneko/commits/949d5a7ea367207b00428fd9a4381e489cceedb0',
    }
};