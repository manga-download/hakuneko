export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'dffcdc',
        link: 'https://github.com/manga-download/hakuneko/commits/dffcdc69043a4e290416f619bbb474c00be7815f',
    }
};