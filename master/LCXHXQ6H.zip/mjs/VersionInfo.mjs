export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'd725d0',
        link: 'https://github.com/manga-download/hakuneko/commits/d725d0bcd48d6ccce015ae3c4b72f65d6674ed75',
    }
};