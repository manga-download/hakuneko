export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e3f5be',
        link: 'https://github.com/manga-download/hakuneko/commits/e3f5be49c4422353f030b7d2af41a34674adb9eb',
    }
};