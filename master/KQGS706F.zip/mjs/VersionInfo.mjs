export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a0be12',
        link: 'https://github.com/manga-download/hakuneko/commits/a0be12e35c5693f609250f18e77e43f70716f108',
    }
};