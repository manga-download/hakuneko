export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3cb226',
        link: 'https://github.com/manga-download/hakuneko/commits/3cb2267ffc4dbfbf0142c997cf40086af5361419',
    }
};