export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'c753b6',
        link: 'https://github.com/manga-download/hakuneko/commits/c753b66f859d2438b424938b198c73abd513ee81',
    }
};