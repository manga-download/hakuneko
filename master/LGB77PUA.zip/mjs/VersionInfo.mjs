export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1e5ef1',
        link: 'https://github.com/manga-download/hakuneko/commits/1e5ef1ededc92cd1e816601837af76ae9a0e7d0e',
    }
};