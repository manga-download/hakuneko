export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5615ce',
        link: 'https://github.com/manga-download/hakuneko/commits/5615cec11720aa2558f83f7b9b49e4cdbfed7c38',
    }
};