export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'fd5dcb',
        link: 'https://github.com/manga-download/hakuneko/commits/fd5dcb86b5a78938fae3ad3131faa902f644b180',
    }
};