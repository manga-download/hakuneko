export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '8bc101',
        link: 'https://github.com/manga-download/hakuneko/commits/8bc101cf0ca7215d2a62d0b910ad6468a04c703d',
    }
};