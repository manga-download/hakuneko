export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '56b607',
        link: 'https://github.com/manga-download/hakuneko/commits/56b60795dd4f843f4f11d9cb7a766c0fad6235b9',
    }
};