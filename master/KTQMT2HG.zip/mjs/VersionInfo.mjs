export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a11a9b',
        link: 'https://github.com/manga-download/hakuneko/commits/a11a9b8e48743ecd8036b3c2576c8cc92ad57908',
    }
};