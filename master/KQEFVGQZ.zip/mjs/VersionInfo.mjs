export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '754146',
        link: 'https://github.com/manga-download/hakuneko/commits/7541465b8620ded15252d005cda86529b8873612',
    }
};