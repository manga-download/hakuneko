export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1d09cc',
        link: 'https://github.com/manga-download/hakuneko/commits/1d09cc1e9669142e6e4351f92a300e2677133cb5',
    }
};