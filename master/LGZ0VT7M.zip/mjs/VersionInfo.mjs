export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b5df44',
        link: 'https://github.com/manga-download/hakuneko/commits/b5df4426f057664bcbfa7b9ee5d7d3f4127111e1',
    }
};