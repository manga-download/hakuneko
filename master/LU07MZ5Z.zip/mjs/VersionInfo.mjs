export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'c8f5ed',
        link: 'https://github.com/manga-download/hakuneko/commits/c8f5ed628161b602a74e7130cb55697e9dde6755',
    }
};