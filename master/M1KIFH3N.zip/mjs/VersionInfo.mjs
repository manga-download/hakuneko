export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b56850',
        link: 'https://github.com/manga-download/hakuneko/commits/b56850d16d54bfe49baf77bccfb229073ff6c7b2',
    }
};