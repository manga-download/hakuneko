export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'c06c51',
        link: 'https://github.com/manga-download/hakuneko/commits/c06c510a6adb57bef60440ea98afa8511b98e8ef',
    }
};