export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4c80d4',
        link: 'https://github.com/manga-download/hakuneko/commits/4c80d44b1a9f81cf2fd93a33a4eeb20b60e95e10',
    }
};