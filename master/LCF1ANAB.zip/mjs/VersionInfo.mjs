export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5f60a1',
        link: 'https://github.com/manga-download/hakuneko/commits/5f60a1afcec971ec3ad9142765b4dfddb17c1489',
    }
};