export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ccf60a',
        link: 'https://github.com/manga-download/hakuneko/commits/ccf60a8494024e0daac0e2ad64771fd2a8dc9b7c',
    }
};