export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'bccf1d',
        link: 'https://github.com/manga-download/hakuneko/commits/bccf1d8e6d3edb6b4ecbc801863318d97ece8ef2',
    }
};