export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'fa5bd5',
        link: 'https://github.com/manga-download/hakuneko/commits/fa5bd550ea296d3d252892a1847bc9f3118ad954',
    }
};