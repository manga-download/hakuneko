export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f910d0',
        link: 'https://github.com/manga-download/hakuneko/commits/f910d0c0d22a069c5f4054785bfefec7933caa30',
    }
};