export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '6a2b8d',
        link: 'https://github.com/manga-download/hakuneko/commits/6a2b8d68f3288b739d62738140a5a6874ff0b862',
    }
};