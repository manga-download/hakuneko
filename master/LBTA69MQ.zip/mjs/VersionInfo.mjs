export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '377639',
        link: 'https://github.com/manga-download/hakuneko/commits/3776397306c3ec7eb7ababc5f7350b002a81f213',
    }
};