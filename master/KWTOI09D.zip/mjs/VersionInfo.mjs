export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1a57fa',
        link: 'https://github.com/manga-download/hakuneko/commits/1a57fa449e4164dd3522b6bd403095825b5a9777',
    }
};