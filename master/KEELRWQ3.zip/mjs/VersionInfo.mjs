export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'aa9b47',
        link: 'https://github.com/manga-download/hakuneko/commits/aa9b47835b301f0b3bde45038d1988dac0e78aa7',
    }
};