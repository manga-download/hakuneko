export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '247949',
        link: 'https://github.com/manga-download/hakuneko/commits/247949006caf59a4a6f0bd2c41a814858cef8b5b',
    }
};