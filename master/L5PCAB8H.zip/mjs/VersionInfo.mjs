export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b1405c',
        link: 'https://github.com/manga-download/hakuneko/commits/b1405c652b6cc68519f36af584f712eb036c1755',
    }
};