export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '822a64',
        link: 'https://github.com/manga-download/hakuneko/commits/822a6442baeef037244a83e7dd17eeebcb339083',
    }
};