export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '21931e',
        link: 'https://github.com/manga-download/hakuneko/commits/21931e5e59ca75c49453c0b2005da6978c26b74e',
    }
};