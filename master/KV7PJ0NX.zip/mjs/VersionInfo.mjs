export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '20c5e6',
        link: 'https://github.com/manga-download/hakuneko/commits/20c5e61c46b71de379a4635a21018f406d32c42b',
    }
};