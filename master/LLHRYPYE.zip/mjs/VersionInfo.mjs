export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1716da',
        link: 'https://github.com/manga-download/hakuneko/commits/1716da6c283cccd641e875c2bfad68a113d38f4f',
    }
};