export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '360a38',
        link: 'https://github.com/manga-download/hakuneko/commits/360a3870228966a9cae058389d1568cd1cd02486',
    }
};