export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '6a31c1',
        link: 'https://github.com/manga-download/hakuneko/commits/6a31c1fc3cd40292bd436da652c4bb5f25bde07a',
    }
};