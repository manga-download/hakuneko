export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4c66ac',
        link: 'https://github.com/manga-download/hakuneko/commits/4c66ac3fb8a0d1027d1235ad8621748419c787b7',
    }
};