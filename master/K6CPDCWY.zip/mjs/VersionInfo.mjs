export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a49b08',
        link: 'https://github.com/manga-download/hakuneko/commits/a49b08cd1b3cd08b614b3454652a233bbf5d0e0d',
    }
};