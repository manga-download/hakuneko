export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1ee6dc',
        link: 'https://github.com/manga-download/hakuneko/commits/1ee6dc0e1d7d50a913f39b9a149f9e1fbca86240',
    }
};