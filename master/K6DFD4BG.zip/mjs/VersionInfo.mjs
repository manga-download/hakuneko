export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'd2cc69',
        link: 'https://github.com/manga-download/hakuneko/commits/d2cc69e908e0115c57063d7d98afc7be29f6d01a',
    }
};