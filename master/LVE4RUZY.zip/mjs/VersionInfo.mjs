export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4011a9',
        link: 'https://github.com/manga-download/hakuneko/commits/4011a9e3dca82339e2770a73cac7a8683ee11be9',
    }
};