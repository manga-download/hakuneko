export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '26d79d',
        link: 'https://github.com/manga-download/hakuneko/commits/26d79db9f95c3701add670cc0701a3048884b58e',
    }
};