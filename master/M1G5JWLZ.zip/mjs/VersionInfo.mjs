export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '909b5d',
        link: 'https://github.com/manga-download/hakuneko/commits/909b5d48fc57e0919d9df65a64537ee393071469',
    }
};