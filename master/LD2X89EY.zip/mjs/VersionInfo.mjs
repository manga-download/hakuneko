export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e013cc',
        link: 'https://github.com/manga-download/hakuneko/commits/e013cccf2dd2e9f0f3736b3c0ac1ba6404e33984',
    }
};