export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '2d4a87',
        link: 'https://github.com/manga-download/hakuneko/commits/2d4a87298ec4b33419d934577fccb98328ecf4a1',
    }
};