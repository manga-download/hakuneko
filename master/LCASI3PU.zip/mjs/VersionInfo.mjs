export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ff0053',
        link: 'https://github.com/manga-download/hakuneko/commits/ff00530ec2d752ed054f95e4f6fc722d1880602c',
    }
};