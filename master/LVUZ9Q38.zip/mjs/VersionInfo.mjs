export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '298c97',
        link: 'https://github.com/manga-download/hakuneko/commits/298c97c9571e95a02b0d945c3254e7e4732e6393',
    }
};