export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4f6365',
        link: 'https://github.com/manga-download/hakuneko/commits/4f6365a4f94b36c012e015e9bbd0f799dfb903b7',
    }
};