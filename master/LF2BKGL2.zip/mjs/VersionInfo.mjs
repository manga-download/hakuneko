export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'afe2eb',
        link: 'https://github.com/manga-download/hakuneko/commits/afe2eb5a066575311a16e1cbf7220dea500f6f39',
    }
};