export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3fec0c',
        link: 'https://github.com/manga-download/hakuneko/commits/3fec0c8748f9d218946929b61921f64072c28ed7',
    }
};