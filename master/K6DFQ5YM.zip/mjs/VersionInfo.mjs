export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4c9dcf',
        link: 'https://github.com/manga-download/hakuneko/commits/4c9dcf9dd3c489e281ccbaa40d252326e7f53c9b',
    }
};