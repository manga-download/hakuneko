export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '88e7fb',
        link: 'https://github.com/manga-download/hakuneko/commits/88e7fb6d61c7d53c604297132e49c200d6ce22de',
    }
};