export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '2fe084',
        link: 'https://github.com/manga-download/hakuneko/commits/2fe084fa302897bdc7749cd9c3aa4ab03e6553ba',
    }
};