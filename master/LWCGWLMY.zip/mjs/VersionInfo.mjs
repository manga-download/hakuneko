export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '54fbc6',
        link: 'https://github.com/manga-download/hakuneko/commits/54fbc6164d26fae967dcc58e70c086592d005f90',
    }
};