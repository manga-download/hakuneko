export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b44368',
        link: 'https://github.com/manga-download/hakuneko/commits/b4436812a4321a90dd2a82d0cfa42b7f77431b33',
    }
};