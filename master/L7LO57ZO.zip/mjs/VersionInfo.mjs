export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f4c2cb',
        link: 'https://github.com/manga-download/hakuneko/commits/f4c2cb5638c5704750027df32e604980cf5983f2',
    }
};