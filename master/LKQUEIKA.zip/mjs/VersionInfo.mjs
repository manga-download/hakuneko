export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'bcb5c2',
        link: 'https://github.com/manga-download/hakuneko/commits/bcb5c22225ea013ec35c0ae8bb65328fc93326f5',
    }
};