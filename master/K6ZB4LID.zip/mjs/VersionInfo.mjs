export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '338ea5',
        link: 'https://github.com/manga-download/hakuneko/commits/338ea5e5b97eea774278bad6173200471a61b150',
    }
};