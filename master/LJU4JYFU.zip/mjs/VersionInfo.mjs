export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b62fc1',
        link: 'https://github.com/manga-download/hakuneko/commits/b62fc1509c0901dd62850e839bf5c207c13d7979',
    }
};