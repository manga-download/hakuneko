export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'd97a8b',
        link: 'https://github.com/manga-download/hakuneko/commits/d97a8b3449cd2458340dc61d20853799b25e92f5',
    }
};