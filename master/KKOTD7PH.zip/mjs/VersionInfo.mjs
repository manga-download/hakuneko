export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '59abec',
        link: 'https://github.com/manga-download/hakuneko/commits/59abec1894fc53cbda3435bec7ff68c2689395fc',
    }
};