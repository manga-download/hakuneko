export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a22978',
        link: 'https://github.com/manga-download/hakuneko/commits/a22978f277d84487f35bb208dcc391a3b71eecda',
    }
};