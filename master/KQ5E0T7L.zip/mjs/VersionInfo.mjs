export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3982ed',
        link: 'https://github.com/manga-download/hakuneko/commits/3982ed64221b38004c7dbfabce45887b3c6e0797',
    }
};