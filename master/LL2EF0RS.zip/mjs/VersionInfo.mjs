export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '8b9ce9',
        link: 'https://github.com/manga-download/hakuneko/commits/8b9ce92697141733a4125fcef41d4664768a9f78',
    }
};