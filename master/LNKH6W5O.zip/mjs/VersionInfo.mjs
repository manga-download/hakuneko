export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '494028',
        link: 'https://github.com/manga-download/hakuneko/commits/494028f7192203c6022fe4cec612348278c0dfea',
    }
};