export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'c53f14',
        link: 'https://github.com/manga-download/hakuneko/commits/c53f142f52fcd4edbf12685c30b2a3a8048a0eba',
    }
};