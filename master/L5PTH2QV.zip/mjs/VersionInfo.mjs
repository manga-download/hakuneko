export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4c8ecb',
        link: 'https://github.com/manga-download/hakuneko/commits/4c8ecb4105410974506bde645f62de31c3ea1714',
    }
};