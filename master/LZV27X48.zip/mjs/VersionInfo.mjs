export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e40bc3',
        link: 'https://github.com/manga-download/hakuneko/commits/e40bc3a02c6d38d2a3e98f19bbf82ed8becf03b3',
    }
};