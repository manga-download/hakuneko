export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e91b60',
        link: 'https://github.com/manga-download/hakuneko/commits/e91b6063d21d181d03533e08b10e71fad4e6d245',
    }
};