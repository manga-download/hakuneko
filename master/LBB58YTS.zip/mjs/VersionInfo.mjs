export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '9b4a33',
        link: 'https://github.com/manga-download/hakuneko/commits/9b4a338e94e76850a9b86d17b90e7f710c540f58',
    }
};