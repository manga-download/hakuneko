export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4d4a85',
        link: 'https://github.com/manga-download/hakuneko/commits/4d4a856e83cecb2ae76789b90d894db2b0c725ac',
    }
};