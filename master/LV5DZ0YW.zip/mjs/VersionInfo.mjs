export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '34bdd5',
        link: 'https://github.com/manga-download/hakuneko/commits/34bdd562fdcf3b4834d10b0d070fd44e05aac722',
    }
};