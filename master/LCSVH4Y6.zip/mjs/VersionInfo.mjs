export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '89d5b4',
        link: 'https://github.com/manga-download/hakuneko/commits/89d5b4a9195c31eeded000e697af6c28cd1a8bef',
    }
};