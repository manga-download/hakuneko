export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '6684f4',
        link: 'https://github.com/manga-download/hakuneko/commits/6684f40b8b40750056da6a6f273bf47eb5dc5326',
    }
};