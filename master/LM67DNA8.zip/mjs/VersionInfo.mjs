export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f756a0',
        link: 'https://github.com/manga-download/hakuneko/commits/f756a097fb9edaad9d077361a81fe6c8e85507b5',
    }
};