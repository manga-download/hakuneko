export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f5a2af',
        link: 'https://github.com/manga-download/hakuneko/commits/f5a2af8b5532213c96075b1e83bdb3447ad88baa',
    }
};