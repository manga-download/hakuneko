export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '6911e5',
        link: 'https://github.com/manga-download/hakuneko/commits/6911e5319be817e861a1ad197bb9a43272a09d2b',
    }
};