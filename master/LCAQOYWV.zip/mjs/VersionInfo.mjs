export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '53bda1',
        link: 'https://github.com/manga-download/hakuneko/commits/53bda14628b69a5d0cf9c7fe193df173bf722891',
    }
};