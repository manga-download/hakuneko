export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f2f593',
        link: 'https://github.com/manga-download/hakuneko/commits/f2f5931b02a0669e283fa267f726b36406eacd59',
    }
};