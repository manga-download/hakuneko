export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '9ba912',
        link: 'https://github.com/manga-download/hakuneko/commits/9ba912d5328c1cc43ea0c2ee65c854e3d2b57676',
    }
};