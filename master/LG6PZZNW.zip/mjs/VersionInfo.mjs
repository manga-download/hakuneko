export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '244acf',
        link: 'https://github.com/manga-download/hakuneko/commits/244acf07d06059c4342a1a3fb9272213ea51cb41',
    }
};