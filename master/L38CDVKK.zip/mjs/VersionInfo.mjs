export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '688f83',
        link: 'https://github.com/manga-download/hakuneko/commits/688f83c20c1035144ba5866e1d6c83741b4c1884',
    }
};