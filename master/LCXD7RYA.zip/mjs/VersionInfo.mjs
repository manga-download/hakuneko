export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5d1cc6',
        link: 'https://github.com/manga-download/hakuneko/commits/5d1cc6310417c88a324e3bc0727d6002a36d5f6d',
    }
};