export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '19b23e',
        link: 'https://github.com/manga-download/hakuneko/commits/19b23ea54decf4a1101fee3b7e888ca0ce95074d',
    }
};