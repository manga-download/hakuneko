export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a93c5e',
        link: 'https://github.com/manga-download/hakuneko/commits/a93c5e870df687bc69947d85e109d43f2a3e0e8a',
    }
};