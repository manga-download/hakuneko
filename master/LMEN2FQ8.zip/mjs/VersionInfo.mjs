export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '55ebf7',
        link: 'https://github.com/manga-download/hakuneko/commits/55ebf7534096ba98e10006f470ee7054a4f790c5',
    }
};