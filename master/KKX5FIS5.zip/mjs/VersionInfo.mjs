export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e6504f',
        link: 'https://github.com/manga-download/hakuneko/commits/e6504f5e81611575dc7585225a5c330ce88a24a4',
    }
};