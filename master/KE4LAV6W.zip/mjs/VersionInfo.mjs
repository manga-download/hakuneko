export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3b0108',
        link: 'https://github.com/manga-download/hakuneko/commits/3b01084a2a23b466e967bed3e0b660adb0f15eb2',
    }
};