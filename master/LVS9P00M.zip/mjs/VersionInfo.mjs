export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '01d735',
        link: 'https://github.com/manga-download/hakuneko/commits/01d735c67fd861b6475660e382963081c43c1585',
    }
};