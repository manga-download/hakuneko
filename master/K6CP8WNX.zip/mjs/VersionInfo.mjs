export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1ae82f',
        link: 'https://github.com/manga-download/hakuneko/commits/1ae82f1a8cfabec589d0fdad7e6eacb76aeb1fb5',
    }
};