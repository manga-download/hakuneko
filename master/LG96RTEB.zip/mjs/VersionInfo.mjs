export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'fa0ef5',
        link: 'https://github.com/manga-download/hakuneko/commits/fa0ef5aae43395daced21984fa6d56dcd05e1ba7',
    }
};