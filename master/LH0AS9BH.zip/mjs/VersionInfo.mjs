export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f9f1f9',
        link: 'https://github.com/manga-download/hakuneko/commits/f9f1f926778e532a855d8c3870d7394d33fb3c62',
    }
};