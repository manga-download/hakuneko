export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'd646cc',
        link: 'https://github.com/manga-download/hakuneko/commits/d646cc2e842fbfdfdc4776d2c686f29adf0911aa',
    }
};