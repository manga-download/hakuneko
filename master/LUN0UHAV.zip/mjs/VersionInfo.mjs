export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'eecc59',
        link: 'https://github.com/manga-download/hakuneko/commits/eecc59f8531f2587b0b78d325c03c06b189b2dfa',
    }
};