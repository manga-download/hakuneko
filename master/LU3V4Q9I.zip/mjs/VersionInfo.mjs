export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '29f362',
        link: 'https://github.com/manga-download/hakuneko/commits/29f362260c0d92d4ddbf8d6aba723c9fc0c5c863',
    }
};