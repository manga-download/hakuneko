export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '883631',
        link: 'https://github.com/manga-download/hakuneko/commits/8836318914dab260e6e0cc6a6419c2bb5d4902b6',
    }
};