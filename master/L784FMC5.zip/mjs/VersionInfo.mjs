export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ca9bdb',
        link: 'https://github.com/manga-download/hakuneko/commits/ca9bdbe0ff0da7e9c9d73ee69011b3f43ad29eb4',
    }
};