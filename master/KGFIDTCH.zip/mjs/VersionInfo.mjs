export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '8d725e',
        link: 'https://github.com/manga-download/hakuneko/commits/8d725e3be8bd3a6a881d8a5070bacb6a45e3df97',
    }
};