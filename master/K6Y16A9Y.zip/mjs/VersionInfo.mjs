export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a3207c',
        link: 'https://github.com/manga-download/hakuneko/commits/a3207ca0a304f4e5588426b077fd654a571654b7',
    }
};