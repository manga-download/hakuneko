export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f410b8',
        link: 'https://github.com/manga-download/hakuneko/commits/f410b85770a52dae8c5a91451f8181aa6db62ebb',
    }
};