export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '756caa',
        link: 'https://github.com/manga-download/hakuneko/commits/756caababa956afd20b4940ea145115278389b59',
    }
};