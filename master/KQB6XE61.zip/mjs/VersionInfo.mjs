export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'dad923',
        link: 'https://github.com/manga-download/hakuneko/commits/dad923f68a5f60f503fca4b811b472ea805777ea',
    }
};