export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'dd5910',
        link: 'https://github.com/manga-download/hakuneko/commits/dd59107eb47e5c0b6a2a4211e231def4cd6ebde8',
    }
};