export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a94514',
        link: 'https://github.com/manga-download/hakuneko/commits/a945140567c945e38d0aa3a89ba8f93bd542dd0d',
    }
};