export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4165fd',
        link: 'https://github.com/manga-download/hakuneko/commits/4165fdafb4a05df87687cf418f6e5e65240aa308',
    }
};