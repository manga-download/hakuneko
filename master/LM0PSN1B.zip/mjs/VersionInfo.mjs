export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b98eeb',
        link: 'https://github.com/manga-download/hakuneko/commits/b98eebddc62117a4b4de7154e0fe754fe528e28b',
    }
};