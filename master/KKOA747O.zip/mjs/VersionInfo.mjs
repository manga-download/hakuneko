export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '8dcbd5',
        link: 'https://github.com/manga-download/hakuneko/commits/8dcbd5e9a06a57d041c0310156a732244341290c',
    }
};