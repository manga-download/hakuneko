export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f595f0',
        link: 'https://github.com/manga-download/hakuneko/commits/f595f0fae209e00b678702e9d44ece10a290105f',
    }
};