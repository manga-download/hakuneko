export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'bc085d',
        link: 'https://github.com/manga-download/hakuneko/commits/bc085d43f5108644170d3dbc71f1a85723a795d1',
    }
};