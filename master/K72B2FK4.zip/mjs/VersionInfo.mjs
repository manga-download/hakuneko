export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b184c0',
        link: 'https://github.com/manga-download/hakuneko/commits/b184c09ed5a65e8e29097d7f9662af2a03368c39',
    }
};