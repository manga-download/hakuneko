export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '7c0bca',
        link: 'https://github.com/manga-download/hakuneko/commits/7c0bcaa4fa4591957a1c4f197579c912c57d037c',
    }
};