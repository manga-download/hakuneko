export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e53409',
        link: 'https://github.com/manga-download/hakuneko/commits/e53409e59c4ad76ed91aa209a7afe08a3b2ae641',
    }
};