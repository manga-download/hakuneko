export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'dc8506',
        link: 'https://github.com/manga-download/hakuneko/commits/dc850613fbb113ad22b0b3b01d3627f56882d9e2',
    }
};