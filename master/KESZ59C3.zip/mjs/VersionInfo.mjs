export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '24e98a',
        link: 'https://github.com/manga-download/hakuneko/commits/24e98a3c1798c97ac4202758abb087a298ed4845',
    }
};