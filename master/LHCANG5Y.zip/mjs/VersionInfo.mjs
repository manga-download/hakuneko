export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e50dca',
        link: 'https://github.com/manga-download/hakuneko/commits/e50dca3fe0c2455981d901c16db7586d9bc0dc65',
    }
};