export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '62c509',
        link: 'https://github.com/manga-download/hakuneko/commits/62c5099c0558e540873d0ad036bf38ebd679c869',
    }
};