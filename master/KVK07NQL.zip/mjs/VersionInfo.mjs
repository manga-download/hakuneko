export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f459c6',
        link: 'https://github.com/manga-download/hakuneko/commits/f459c65c73ec0f54796aadd2cc1006d387d10fac',
    }
};