export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'bdaf87',
        link: 'https://github.com/manga-download/hakuneko/commits/bdaf879616c77a0b69b264bc590eb78845ac4643',
    }
};