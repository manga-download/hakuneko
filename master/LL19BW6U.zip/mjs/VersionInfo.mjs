export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ba54db',
        link: 'https://github.com/manga-download/hakuneko/commits/ba54dbed9576eb994aa1152712453e158624eb07',
    }
};