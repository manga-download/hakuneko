export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e79723',
        link: 'https://github.com/manga-download/hakuneko/commits/e79723ae73600b918ecc9d8712d11ecc7ce94039',
    }
};