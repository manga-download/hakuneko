export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '115fc6',
        link: 'https://github.com/manga-download/hakuneko/commits/115fc6980144d26befcf44598fa1c3ddffcb3106',
    }
};