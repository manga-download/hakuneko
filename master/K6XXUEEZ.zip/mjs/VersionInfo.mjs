export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '22c69a',
        link: 'https://github.com/manga-download/hakuneko/commits/22c69a48140c8e1c966ac0b03f176f7f60e4e0b1',
    }
};