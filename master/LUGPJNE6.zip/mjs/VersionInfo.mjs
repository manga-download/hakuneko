export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4448f8',
        link: 'https://github.com/manga-download/hakuneko/commits/4448f8ff32bd7775e434f9b5201b1cae23392d4c',
    }
};