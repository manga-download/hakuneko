export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e16831',
        link: 'https://github.com/manga-download/hakuneko/commits/e168315ff655b146b28f9aedff9563e0fdff08e5',
    }
};