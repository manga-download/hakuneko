export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1e255e',
        link: 'https://github.com/manga-download/hakuneko/commits/1e255e85c6e4a97a6e89e6bffc341d7d932dad8e',
    }
};