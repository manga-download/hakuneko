export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ca22d1',
        link: 'https://github.com/manga-download/hakuneko/commits/ca22d1cc2b7801f75ab16ff4a2008d3b4222a331',
    }
};