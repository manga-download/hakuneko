export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'aea99f',
        link: 'https://github.com/manga-download/hakuneko/commits/aea99f9d202a2f568e529123bfcc9befb88eb73e',
    }
};