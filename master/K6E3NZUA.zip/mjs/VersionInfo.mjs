export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'c4393b',
        link: 'https://github.com/manga-download/hakuneko/commits/c4393b91a991a493e9ff8963f4c057b040fd24d3',
    }
};