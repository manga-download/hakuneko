export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '008f17',
        link: 'https://github.com/manga-download/hakuneko/commits/008f171cfe99e9a8eb68ff52ac8a5f5a98be89ba',
    }
};