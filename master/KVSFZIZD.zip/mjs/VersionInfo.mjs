export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '2642e7',
        link: 'https://github.com/manga-download/hakuneko/commits/2642e7dd7c3df476e41b495108292a23ac8e7269',
    }
};