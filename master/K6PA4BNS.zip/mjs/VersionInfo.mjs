export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '08403c',
        link: 'https://github.com/manga-download/hakuneko/commits/08403c7763d13ccfdd92c680ef961ec74c3652f6',
    }
};