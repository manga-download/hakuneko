export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '755434',
        link: 'https://github.com/manga-download/hakuneko/commits/755434f8a9cf626ef159a478a2f674a5d05c0e4c',
    }
};