export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '9771f1',
        link: 'https://github.com/manga-download/hakuneko/commits/9771f1e90728ea3789741c4dbbf617971ae9c0b5',
    }
};