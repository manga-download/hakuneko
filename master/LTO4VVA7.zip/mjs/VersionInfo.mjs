export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f3c17d',
        link: 'https://github.com/manga-download/hakuneko/commits/f3c17dc2d7784c9cd04ffc2630eba701c991e268',
    }
};