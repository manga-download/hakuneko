export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '99f9e9',
        link: 'https://github.com/manga-download/hakuneko/commits/99f9e91d75eb6d3d8c146c31e51378e2b4eac4e5',
    }
};