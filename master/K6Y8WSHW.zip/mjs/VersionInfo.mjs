export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'd54d5f',
        link: 'https://github.com/manga-download/hakuneko/commits/d54d5fc1eccddc67ede4239e7df65f7c746178b2',
    }
};