export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b58672',
        link: 'https://github.com/manga-download/hakuneko/commits/b586725306b68d26012e6a4bccd9163996256ea9',
    }
};