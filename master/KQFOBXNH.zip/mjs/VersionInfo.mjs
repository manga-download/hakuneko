export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '865aa1',
        link: 'https://github.com/manga-download/hakuneko/commits/865aa13db8136714b8b586aa73f5399eac245796',
    }
};