export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '258165',
        link: 'https://github.com/manga-download/hakuneko/commits/258165d87f3152361ff7a1b4595b66f28e6f4717',
    }
};