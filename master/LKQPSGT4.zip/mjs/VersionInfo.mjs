export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'cae961',
        link: 'https://github.com/manga-download/hakuneko/commits/cae961396226257b3b7bf554e201a1f50a863b50',
    }
};