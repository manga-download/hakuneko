export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3ab89a',
        link: 'https://github.com/manga-download/hakuneko/commits/3ab89a9435823917def09aada1eaad0f739fa461',
    }
};