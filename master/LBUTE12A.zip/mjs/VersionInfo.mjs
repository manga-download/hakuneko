export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5b1d29',
        link: 'https://github.com/manga-download/hakuneko/commits/5b1d299bf121cd2355aca5df2cfccc229a852c8c',
    }
};