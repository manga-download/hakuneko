export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'df90a1',
        link: 'https://github.com/manga-download/hakuneko/commits/df90a160b931b566ea3bcfde8954a0a93a9d8e90',
    }
};