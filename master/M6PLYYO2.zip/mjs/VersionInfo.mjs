export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f35fa3',
        link: 'https://github.com/manga-download/hakuneko/commits/f35fa387d3a42c133ed25b8919df4381252a4bca',
    }
};