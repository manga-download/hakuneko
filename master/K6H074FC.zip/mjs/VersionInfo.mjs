export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e7ba96',
        link: 'https://github.com/manga-download/hakuneko/commits/e7ba9615e1945ef457642b651a807a0c779ee961',
    }
};