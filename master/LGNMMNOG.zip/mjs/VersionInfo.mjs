export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'df4ba9',
        link: 'https://github.com/manga-download/hakuneko/commits/df4ba95a82ce656f73ff2ccfb8d38600152558f2',
    }
};