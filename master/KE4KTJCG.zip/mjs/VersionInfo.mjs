export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '913d73',
        link: 'https://github.com/manga-download/hakuneko/commits/913d73cb6aeb87bad859070d0c49ba20dfd28b36',
    }
};