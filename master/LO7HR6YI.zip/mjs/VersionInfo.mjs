export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '28d84c',
        link: 'https://github.com/manga-download/hakuneko/commits/28d84c770f19d58f5cc77a97cfc2017c2e201740',
    }
};