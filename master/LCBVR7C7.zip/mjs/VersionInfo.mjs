export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ad559b',
        link: 'https://github.com/manga-download/hakuneko/commits/ad559bcb1d17de425ba0cce1097de83116978c69',
    }
};