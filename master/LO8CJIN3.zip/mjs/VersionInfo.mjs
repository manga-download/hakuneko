export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4a29b4',
        link: 'https://github.com/manga-download/hakuneko/commits/4a29b4c79a7de11723fbf651e42055e765333933',
    }
};