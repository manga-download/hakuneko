export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '9f0438',
        link: 'https://github.com/manga-download/hakuneko/commits/9f043848e4451c48cd0735547d10b4efa9f091e0',
    }
};