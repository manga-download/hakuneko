export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b43e61',
        link: 'https://github.com/manga-download/hakuneko/commits/b43e61962200f451ad65964c8827f7ee68d82b2c',
    }
};