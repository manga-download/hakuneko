export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'cdbd97',
        link: 'https://github.com/manga-download/hakuneko/commits/cdbd979a3995ae65dd166471c4d5e952adc3b591',
    }
};