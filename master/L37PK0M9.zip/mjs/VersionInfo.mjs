export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4c64e9',
        link: 'https://github.com/manga-download/hakuneko/commits/4c64e925ec5feb9fe6b5cc47ba3e756cf4093022',
    }
};