export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '59e386',
        link: 'https://github.com/manga-download/hakuneko/commits/59e386321bf288583005e95644c534cb87bc2aba',
    }
};