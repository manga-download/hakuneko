export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '228aaf',
        link: 'https://github.com/manga-download/hakuneko/commits/228aaf8e8e52bfc0183313a48d4bf3f8a0ba3f01',
    }
};