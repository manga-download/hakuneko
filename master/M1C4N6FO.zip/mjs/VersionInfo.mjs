export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '2539ae',
        link: 'https://github.com/manga-download/hakuneko/commits/2539ae974a128688a4f1ae5ba60ead38cec5b113',
    }
};