export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e58a1e',
        link: 'https://github.com/manga-download/hakuneko/commits/e58a1e17ec3c031d753aca5194d1e1c6e08030ea',
    }
};