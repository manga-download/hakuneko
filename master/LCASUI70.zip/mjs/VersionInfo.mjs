export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b90d5d',
        link: 'https://github.com/manga-download/hakuneko/commits/b90d5dd2e210cbed98c5c133cb91807c95589144',
    }
};