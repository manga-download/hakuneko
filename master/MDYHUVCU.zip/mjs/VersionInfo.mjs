export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '29a9cb',
        link: 'https://github.com/manga-download/hakuneko/commits/29a9cb5ce8d1ad6fc2e3275243c8259b5f6f2886',
    }
};