export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ab3606',
        link: 'https://github.com/manga-download/hakuneko/commits/ab3606fe5fa42b22c5283d2a6a35df11fc8b2381',
    }
};