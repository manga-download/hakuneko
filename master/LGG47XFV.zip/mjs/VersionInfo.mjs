export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5c3f74',
        link: 'https://github.com/manga-download/hakuneko/commits/5c3f74f3da4d755f3f10d11e177b3ab1f7edd544',
    }
};