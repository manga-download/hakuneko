export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3a5018',
        link: 'https://github.com/manga-download/hakuneko/commits/3a50183c145c9530f3d6f540132ba26a702833fe',
    }
};