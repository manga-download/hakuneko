export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a588ad',
        link: 'https://github.com/manga-download/hakuneko/commits/a588aded47b7991867d74204bcb263af6ca0d901',
    }
};