export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'af9f1f',
        link: 'https://github.com/manga-download/hakuneko/commits/af9f1f325666bed33363a935aa2b7de3975d08c0',
    }
};