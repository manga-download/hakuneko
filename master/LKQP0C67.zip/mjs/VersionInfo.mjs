export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '97d8dc',
        link: 'https://github.com/manga-download/hakuneko/commits/97d8dcd6ea8a382600532f8ebc53b0f3a79afc74',
    }
};