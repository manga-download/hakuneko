export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1339ec',
        link: 'https://github.com/manga-download/hakuneko/commits/1339ec1b98d48dfa75a02d00975ca9a5882a385e',
    }
};