export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'baf214',
        link: 'https://github.com/manga-download/hakuneko/commits/baf21470cb806b20a72b29a42d4ef2f96e160d23',
    }
};