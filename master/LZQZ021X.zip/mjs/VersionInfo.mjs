export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '306df4',
        link: 'https://github.com/manga-download/hakuneko/commits/306df4e381896cbcac4b0e681c1b56c9fa766c60',
    }
};