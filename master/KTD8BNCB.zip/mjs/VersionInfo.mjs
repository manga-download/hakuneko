export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'd6503c',
        link: 'https://github.com/manga-download/hakuneko/commits/d6503c91914014878bc399c7a7583b3c08f3b9c8',
    }
};