export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '32246d',
        link: 'https://github.com/manga-download/hakuneko/commits/32246d99020eee2489e76c6f7730db4748c36d30',
    }
};