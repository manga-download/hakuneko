export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'bbe339',
        link: 'https://github.com/manga-download/hakuneko/commits/bbe339357da44c1beff343bd0fbf584de5dad3e4',
    }
};