export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e57e97',
        link: 'https://github.com/manga-download/hakuneko/commits/e57e974dac9150a6c2a6a61d04fde967725097c8',
    }
};