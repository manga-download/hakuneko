export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e0ecd1',
        link: 'https://github.com/manga-download/hakuneko/commits/e0ecd125f1d39c746156b73b225c4e80f7e8d61c',
    }
};