export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '346eb4',
        link: 'https://github.com/manga-download/hakuneko/commits/346eb4fdcf8c075a48f86a7d82bd9886c191539d',
    }
};