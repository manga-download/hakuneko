export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '33e01f',
        link: 'https://github.com/manga-download/hakuneko/commits/33e01f4d5057d6a1562eb05fe10133b364c17636',
    }
};