export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'c7c8a4',
        link: 'https://github.com/manga-download/hakuneko/commits/c7c8a43197bacd1d3770e7932205d75a5ed1089c',
    }
};