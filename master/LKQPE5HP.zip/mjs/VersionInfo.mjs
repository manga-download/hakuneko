export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b8fd8c',
        link: 'https://github.com/manga-download/hakuneko/commits/b8fd8c3dbceb217df166c2fa1a827ab29163bc38',
    }
};