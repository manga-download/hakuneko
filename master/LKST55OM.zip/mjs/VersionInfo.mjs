export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '6ddc3b',
        link: 'https://github.com/manga-download/hakuneko/commits/6ddc3bee0f35b24cd42c0939d628f7aa88235559',
    }
};