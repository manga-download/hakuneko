export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '2d3f3e',
        link: 'https://github.com/manga-download/hakuneko/commits/2d3f3e851399b31560e8107e8ae9483f09d140d3',
    }
};