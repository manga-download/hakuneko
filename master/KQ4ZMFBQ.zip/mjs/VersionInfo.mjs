export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4ffc07',
        link: 'https://github.com/manga-download/hakuneko/commits/4ffc07067e5246fbe1b6a269e6ed7770aa9a2cd4',
    }
};