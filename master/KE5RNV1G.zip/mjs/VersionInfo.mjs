export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '957ceb',
        link: 'https://github.com/manga-download/hakuneko/commits/957ceb88cd75fc4b6e263ce6546982dea7d24704',
    }
};