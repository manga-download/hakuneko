export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e83910',
        link: 'https://github.com/manga-download/hakuneko/commits/e83910e379f50eae75172abe4a9713756bc64373',
    }
};