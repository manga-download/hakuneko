export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'be6883',
        link: 'https://github.com/manga-download/hakuneko/commits/be68836df22feed98d18b266efb7d63a0857320b',
    }
};