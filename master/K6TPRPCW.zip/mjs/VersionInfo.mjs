export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '0fed5c',
        link: 'https://github.com/manga-download/hakuneko/commits/0fed5c1bd14a90ab7755b6dd82d9190ac7736085',
    }
};