export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '330cb1',
        link: 'https://github.com/manga-download/hakuneko/commits/330cb1525d16c75701f4ffedc0fb1357a5c0eaca',
    }
};