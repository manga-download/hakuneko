export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '6226cc',
        link: 'https://github.com/manga-download/hakuneko/commits/6226ccb249124a09ff79dd5a6211bccaf3ba33ae',
    }
};