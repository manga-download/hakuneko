export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ba8ae4',
        link: 'https://github.com/manga-download/hakuneko/commits/ba8ae4b935f7ab0ab1e067722ac474145f7e172f',
    }
};