export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f3a128',
        link: 'https://github.com/manga-download/hakuneko/commits/f3a1289213fd9c92cb1d04606957d2fc20bd1c16',
    }
};