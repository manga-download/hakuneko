export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e86c9d',
        link: 'https://github.com/manga-download/hakuneko/commits/e86c9d48567e7cc1397b82f3288defe80fc357f6',
    }
};