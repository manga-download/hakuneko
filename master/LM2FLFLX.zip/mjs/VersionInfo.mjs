export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '47996a',
        link: 'https://github.com/manga-download/hakuneko/commits/47996a9d325fd6364b55c8379f47fec6607b5711',
    }
};