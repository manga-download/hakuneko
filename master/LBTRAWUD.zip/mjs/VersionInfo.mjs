export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '6cc694',
        link: 'https://github.com/manga-download/hakuneko/commits/6cc694cb5f90a8dae0bb768f6fede62eaadacc99',
    }
};