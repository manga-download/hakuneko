export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '54480c',
        link: 'https://github.com/manga-download/hakuneko/commits/54480c647f815b1ebfc37a9c46d185c8dc691a50',
    }
};