export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'bef0c9',
        link: 'https://github.com/manga-download/hakuneko/commits/bef0c925b419ff187b18ad2998380fa98b80a5f6',
    }
};