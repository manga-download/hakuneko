export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '058d87',
        link: 'https://github.com/manga-download/hakuneko/commits/058d8770926e6ce2ef4d26879098e7da956c6c45',
    }
};