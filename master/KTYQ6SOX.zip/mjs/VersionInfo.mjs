export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ec9711',
        link: 'https://github.com/manga-download/hakuneko/commits/ec9711a2bbc6ce865a83ae5433548687b1b9be5c',
    }
};