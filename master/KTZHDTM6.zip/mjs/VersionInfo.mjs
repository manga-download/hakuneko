export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '0593a8',
        link: 'https://github.com/manga-download/hakuneko/commits/0593a8cb8824e8753209c3fb0d6b9275a1c0b2e8',
    }
};