export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'dde90a',
        link: 'https://github.com/manga-download/hakuneko/commits/dde90a5f78cc2e35e7ac858069f9be455fa689fa',
    }
};