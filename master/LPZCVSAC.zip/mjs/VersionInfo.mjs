export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'd80b6f',
        link: 'https://github.com/manga-download/hakuneko/commits/d80b6f4fa2cf41b34adc06077ed7df55444fcdc0',
    }
};