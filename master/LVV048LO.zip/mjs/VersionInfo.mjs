export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ae0af5',
        link: 'https://github.com/manga-download/hakuneko/commits/ae0af51a87f4dcbd4e4854d195c1090e6f8dfa17',
    }
};