export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '24363e',
        link: 'https://github.com/manga-download/hakuneko/commits/24363e34e9926475e0e57363c62cfca48e4a1634',
    }
};