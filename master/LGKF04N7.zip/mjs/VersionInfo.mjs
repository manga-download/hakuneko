export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ca83d7',
        link: 'https://github.com/manga-download/hakuneko/commits/ca83d79c1baf8dacc59887977d85579bf5d4e476',
    }
};