export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '64e144',
        link: 'https://github.com/manga-download/hakuneko/commits/64e1441e036c3d363323659d6e42f875f7651d17',
    }
};