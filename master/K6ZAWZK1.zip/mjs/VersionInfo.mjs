export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f4aa3e',
        link: 'https://github.com/manga-download/hakuneko/commits/f4aa3ec1b2371b694aa86cab0a3fa7a4a3499863',
    }
};