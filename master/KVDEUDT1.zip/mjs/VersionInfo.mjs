export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a7df79',
        link: 'https://github.com/manga-download/hakuneko/commits/a7df7923b32aebfd8660e50496a22469538ce75f',
    }
};