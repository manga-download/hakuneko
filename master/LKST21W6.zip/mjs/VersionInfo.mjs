export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ef4d21',
        link: 'https://github.com/manga-download/hakuneko/commits/ef4d212a21b84dfb212fb1a14054e013621d1914',
    }
};