export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '7cbc09',
        link: 'https://github.com/manga-download/hakuneko/commits/7cbc0907fbffc5ca8997cadfcc3004d083936844',
    }
};