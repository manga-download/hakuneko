export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '0e4869',
        link: 'https://github.com/manga-download/hakuneko/commits/0e486959f2659855b733df38fde2dc3a3837dd4e',
    }
};