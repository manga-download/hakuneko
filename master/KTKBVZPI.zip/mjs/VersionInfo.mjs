export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '77ed7a',
        link: 'https://github.com/manga-download/hakuneko/commits/77ed7ab56681a602ff1ef59a906852f922b42ba0',
    }
};