export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b22f73',
        link: 'https://github.com/manga-download/hakuneko/commits/b22f73eebdc1580b8ba9fbe1076790204fdcc596',
    }
};