export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b8f677',
        link: 'https://github.com/manga-download/hakuneko/commits/b8f677bcbe16f8206f0993cda96d0f7ff6583921',
    }
};