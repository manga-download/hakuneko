export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '2605de',
        link: 'https://github.com/manga-download/hakuneko/commits/2605de7b975d1ad01c139f8b9aeaae647d133bf6',
    }
};