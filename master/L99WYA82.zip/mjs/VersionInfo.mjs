export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'dc1a9c',
        link: 'https://github.com/manga-download/hakuneko/commits/dc1a9c72c08c53a956f7d17371e226b5af8a0173',
    }
};