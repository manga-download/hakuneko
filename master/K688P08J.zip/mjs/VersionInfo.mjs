export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ddbdf8',
        link: 'https://github.com/manga-download/hakuneko/commits/ddbdf8dc9e4c425e26e0c6d2ff4314553eefebf2',
    }
};