export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '6637e4',
        link: 'https://github.com/manga-download/hakuneko/commits/6637e46432b961ad44a04b1237bb679d061c0aa0',
    }
};