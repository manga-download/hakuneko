export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '41af97',
        link: 'https://github.com/manga-download/hakuneko/commits/41af9765d1bcc7942743ab22b6fea3a29f09ac37',
    }
};