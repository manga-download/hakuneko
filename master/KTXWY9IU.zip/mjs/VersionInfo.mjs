export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'af98e7',
        link: 'https://github.com/manga-download/hakuneko/commits/af98e7741738c8d9949b4cdce1e8e2dd0e3a7839',
    }
};