export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'd936eb',
        link: 'https://github.com/manga-download/hakuneko/commits/d936eb2423d1a48f1dccb67041d8df1974425e77',
    }
};