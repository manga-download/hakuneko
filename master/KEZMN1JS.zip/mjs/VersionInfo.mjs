export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '6b0d7d',
        link: 'https://github.com/manga-download/hakuneko/commits/6b0d7d7038e9e9b3ac06cd22f829d43226d443c8',
    }
};