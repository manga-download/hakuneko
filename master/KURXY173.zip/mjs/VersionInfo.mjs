export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ae208d',
        link: 'https://github.com/manga-download/hakuneko/commits/ae208d42eb64fcdf64f8d71f7b6b318745d39da1',
    }
};