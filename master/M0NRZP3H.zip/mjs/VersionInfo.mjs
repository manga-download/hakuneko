export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f206c3',
        link: 'https://github.com/manga-download/hakuneko/commits/f206c3990ca40d4a0a1a41151ae873e256e8d053',
    }
};