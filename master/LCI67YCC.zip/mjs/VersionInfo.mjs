export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'bac762',
        link: 'https://github.com/manga-download/hakuneko/commits/bac7625972869354383aaf6760719b3a855d35df',
    }
};