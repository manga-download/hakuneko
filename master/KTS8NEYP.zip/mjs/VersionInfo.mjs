export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'cf8808',
        link: 'https://github.com/manga-download/hakuneko/commits/cf88080eca5eab92dd989b7378194a1bc00f7df7',
    }
};