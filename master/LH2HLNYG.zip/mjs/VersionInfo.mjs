export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e13f93',
        link: 'https://github.com/manga-download/hakuneko/commits/e13f939eed3a4dcdfe1526a12bace8f7aa0fb6ac',
    }
};