export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '58182d',
        link: 'https://github.com/manga-download/hakuneko/commits/58182d525a10c706d3dc2a25cf0438f8167dc225',
    }
};