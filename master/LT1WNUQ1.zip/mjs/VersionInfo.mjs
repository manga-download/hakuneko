export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5dae34',
        link: 'https://github.com/manga-download/hakuneko/commits/5dae3445f6bfa3e31515fe9cdba738f0091e4a64',
    }
};