export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4ec589',
        link: 'https://github.com/manga-download/hakuneko/commits/4ec5897d0dc8e00743aa9cd16b311ae636777006',
    }
};