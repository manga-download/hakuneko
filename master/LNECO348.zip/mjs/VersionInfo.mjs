export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '42a27e',
        link: 'https://github.com/manga-download/hakuneko/commits/42a27ec3309fa9874b3dcc2f191b80d67ebd540b',
    }
};