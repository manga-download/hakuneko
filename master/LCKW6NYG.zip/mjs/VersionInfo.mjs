export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '673154',
        link: 'https://github.com/manga-download/hakuneko/commits/673154d3cd92b2e9a48d4eee90dbfcba16077598',
    }
};