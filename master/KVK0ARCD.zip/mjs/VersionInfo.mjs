export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'af6357',
        link: 'https://github.com/manga-download/hakuneko/commits/af63578ce7a9c508b3a55fcfe0a90a014c48dd80',
    }
};