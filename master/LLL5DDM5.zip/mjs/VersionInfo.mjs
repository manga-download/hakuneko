export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '50fb29',
        link: 'https://github.com/manga-download/hakuneko/commits/50fb2932aacc4cc45f79a5bb36a7acb0db73a7f7',
    }
};