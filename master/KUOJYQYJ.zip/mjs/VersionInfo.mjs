export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '8d5142',
        link: 'https://github.com/manga-download/hakuneko/commits/8d51423bbe3f635a7c0368955604b221dbf96f8b',
    }
};