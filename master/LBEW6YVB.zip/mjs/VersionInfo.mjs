export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1d2ce3',
        link: 'https://github.com/manga-download/hakuneko/commits/1d2ce32e88c60615f7fc51dd1a0e801ab3db5506',
    }
};