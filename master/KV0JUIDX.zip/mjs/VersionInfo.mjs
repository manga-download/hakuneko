export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'bd6623',
        link: 'https://github.com/manga-download/hakuneko/commits/bd6623ef8450c5201896333897105a92b6e47e04',
    }
};