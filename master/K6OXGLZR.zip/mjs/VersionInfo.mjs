export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '76ff34',
        link: 'https://github.com/manga-download/hakuneko/commits/76ff342c52e0bbaa28ce6075b6c9517944bbf22e',
    }
};