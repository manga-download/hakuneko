export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '0c07e8',
        link: 'https://github.com/manga-download/hakuneko/commits/0c07e8fad6e0ab954899c69cb96e4a28c259f6d7',
    }
};