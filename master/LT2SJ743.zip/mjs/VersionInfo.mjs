export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b59a08',
        link: 'https://github.com/manga-download/hakuneko/commits/b59a08f966fb42ff716259df281c8634573cb6cb',
    }
};