export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '458f46',
        link: 'https://github.com/manga-download/hakuneko/commits/458f46c6cc078dcfab347a3f03f7c135ba8eddf4',
    }
};