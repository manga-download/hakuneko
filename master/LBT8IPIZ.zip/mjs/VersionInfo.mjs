export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '00f751',
        link: 'https://github.com/manga-download/hakuneko/commits/00f751e2b5820bcfb9ebaa544c9fa0a431f9d644',
    }
};