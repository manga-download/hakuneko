export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3ec52d',
        link: 'https://github.com/manga-download/hakuneko/commits/3ec52d43f1474680eb62a472ba4db2253f1ad24a',
    }
};