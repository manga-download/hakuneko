export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f9b2b8',
        link: 'https://github.com/manga-download/hakuneko/commits/f9b2b837d62524e13dadd0b0667f9a5aad31bf36',
    }
};