export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3c6968',
        link: 'https://github.com/manga-download/hakuneko/commits/3c6968fd10e9027369494d8db19863348a51c93e',
    }
};