export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '59165b',
        link: 'https://github.com/manga-download/hakuneko/commits/59165b1cac8f3c9e0eeb4d647b6d4065730ee0ef',
    }
};