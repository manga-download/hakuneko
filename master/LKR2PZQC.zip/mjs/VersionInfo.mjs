export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ce7e35',
        link: 'https://github.com/manga-download/hakuneko/commits/ce7e353ceddeef993c84d9db9281cbfa38105945',
    }
};