export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e1fb05',
        link: 'https://github.com/manga-download/hakuneko/commits/e1fb05776b3ac31faa122cdc20e3ec8703a10745',
    }
};