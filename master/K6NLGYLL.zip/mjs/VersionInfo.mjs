export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'fc1717',
        link: 'https://github.com/manga-download/hakuneko/commits/fc17176589a6b1e8e2258c91f11fd43429f3fca8',
    }
};