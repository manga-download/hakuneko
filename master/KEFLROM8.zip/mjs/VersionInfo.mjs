export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a077e3',
        link: 'https://github.com/manga-download/hakuneko/commits/a077e38ff79946085a259aae530e757ffd16eed0',
    }
};