export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a3b10e',
        link: 'https://github.com/manga-download/hakuneko/commits/a3b10e859757701653b4a038ff138391bfc0b3fc',
    }
};