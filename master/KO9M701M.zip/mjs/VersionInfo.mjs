export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '6d5934',
        link: 'https://github.com/manga-download/hakuneko/commits/6d59343821d885f084e584e3dc5827826fe4fb50',
    }
};