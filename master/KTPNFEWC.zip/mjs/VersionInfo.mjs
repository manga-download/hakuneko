export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'aa23cb',
        link: 'https://github.com/manga-download/hakuneko/commits/aa23cb5f038eaa2a1a4a429439760a2a3ae5ce4a',
    }
};