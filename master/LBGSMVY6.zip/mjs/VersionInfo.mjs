export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'cde259',
        link: 'https://github.com/manga-download/hakuneko/commits/cde259724331d34c3095f95bd8305673d95f7f76',
    }
};