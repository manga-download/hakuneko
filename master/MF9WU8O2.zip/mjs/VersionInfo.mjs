export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '13c313',
        link: 'https://github.com/manga-download/hakuneko/commits/13c3135081c56ead79c5191c213d9ccd1eba9e28',
    }
};