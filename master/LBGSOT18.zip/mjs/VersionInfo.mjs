export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '57da68',
        link: 'https://github.com/manga-download/hakuneko/commits/57da6820824bd5255534a947930f789def33da32',
    }
};