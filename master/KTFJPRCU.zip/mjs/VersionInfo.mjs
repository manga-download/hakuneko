export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '43900c',
        link: 'https://github.com/manga-download/hakuneko/commits/43900c1e4e596c261e732b0f5c98170829aa7449',
    }
};