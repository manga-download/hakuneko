export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '0f5320',
        link: 'https://github.com/manga-download/hakuneko/commits/0f5320673b0c7b5109ba2de4087854132a544658',
    }
};