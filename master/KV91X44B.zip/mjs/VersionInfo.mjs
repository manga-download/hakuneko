export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '2d653c',
        link: 'https://github.com/manga-download/hakuneko/commits/2d653c29369426844cd566a5d4f555396fa36b42',
    }
};