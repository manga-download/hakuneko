export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '842287',
        link: 'https://github.com/manga-download/hakuneko/commits/84228706f74373cdb90c4032d12140670f8cdbde',
    }
};