export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'd1f374',
        link: 'https://github.com/manga-download/hakuneko/commits/d1f3749f7b4083a12d1a3f7d6829b852458cf00e',
    }
};