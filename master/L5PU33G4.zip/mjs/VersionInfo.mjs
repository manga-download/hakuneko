export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a04d44',
        link: 'https://github.com/manga-download/hakuneko/commits/a04d44d4d3d313a496fecff7493613165ecc583f',
    }
};