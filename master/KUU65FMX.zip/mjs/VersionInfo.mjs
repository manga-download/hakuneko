export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5e734a',
        link: 'https://github.com/manga-download/hakuneko/commits/5e734a40f3b62833c40dad05b18de8d6c2305673',
    }
};