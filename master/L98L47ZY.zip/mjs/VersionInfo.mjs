export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '8498e1',
        link: 'https://github.com/manga-download/hakuneko/commits/8498e1786d99aa7a5b6a1b865255f85e49ae6ef2',
    }
};