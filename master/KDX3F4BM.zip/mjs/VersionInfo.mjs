export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f00f97',
        link: 'https://github.com/manga-download/hakuneko/commits/f00f9762798a279c4a53199696e44199c7088c75',
    }
};