export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4e785b',
        link: 'https://github.com/manga-download/hakuneko/commits/4e785b0573d42d19b101ca9ce7a2d1cae47b1d92',
    }
};