export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'dc22e7',
        link: 'https://github.com/manga-download/hakuneko/commits/dc22e7ea9ab92cab81c8ad92202b9df5745fc32d',
    }
};