export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f5a429',
        link: 'https://github.com/manga-download/hakuneko/commits/f5a429f9ef5d0bfb04a242b54d9ed101415f45dd',
    }
};