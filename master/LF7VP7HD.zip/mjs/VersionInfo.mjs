export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'bf14d1',
        link: 'https://github.com/manga-download/hakuneko/commits/bf14d1f46321722393f60c0c84da79a8d9e39270',
    }
};