export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a0f951',
        link: 'https://github.com/manga-download/hakuneko/commits/a0f951854b1d673cce97bcf25e9e0053c64936cc',
    }
};