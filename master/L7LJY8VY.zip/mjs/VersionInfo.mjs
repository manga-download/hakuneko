export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '666258',
        link: 'https://github.com/manga-download/hakuneko/commits/6662583b969f92c87c9e00d39fd179eb1147a2af',
    }
};