export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '9c4b8f',
        link: 'https://github.com/manga-download/hakuneko/commits/9c4b8f6090aeb1d4e529aaa4b5acd4672f374de5',
    }
};