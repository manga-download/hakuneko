export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '08ec9d',
        link: 'https://github.com/manga-download/hakuneko/commits/08ec9d79c764623433234c418ba078d30faf5836',
    }
};