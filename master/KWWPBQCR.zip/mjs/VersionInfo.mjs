export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '0a7876',
        link: 'https://github.com/manga-download/hakuneko/commits/0a7876a06de6de8db9733aafe1e56f8a8ab86c2d',
    }
};