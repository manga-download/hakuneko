export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '8e11bd',
        link: 'https://github.com/manga-download/hakuneko/commits/8e11bdb3b76d2b143994474e9ab7d44241944129',
    }
};