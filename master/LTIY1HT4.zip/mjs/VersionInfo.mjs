export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '9754d0',
        link: 'https://github.com/manga-download/hakuneko/commits/9754d0f032869a6805facd68915d1d9e1cf20f39',
    }
};