export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3a34f9',
        link: 'https://github.com/manga-download/hakuneko/commits/3a34f9dc242e9e0f8736dcc71bab4fd0af415763',
    }
};