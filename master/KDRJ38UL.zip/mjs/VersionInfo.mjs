export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3485aa',
        link: 'https://github.com/manga-download/hakuneko/commits/3485aaaf69551e6975fd516bf67e54d83a9cdcbf',
    }
};