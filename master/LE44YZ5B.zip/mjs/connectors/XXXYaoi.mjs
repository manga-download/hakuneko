import WordPressMadara from './templates/WordPressMadara.mjs';

export default class XXXYaoi extends WordPressMadara {

    constructor() {
        super();
        super.id = 'xxxyaoi';
        super.label = 'XXXYaoi';
        this.tags = [ 'hentai', 'high-quality', 'portuguese', 'scanlation' ];
        this.url = 'https://xxxyaoi.com';
    }
}