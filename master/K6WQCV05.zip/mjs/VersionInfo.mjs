export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'c85d84',
        link: 'https://github.com/manga-download/hakuneko/commits/c85d84feb130fc0266f710b15689b12d67dc1b08',
    }
};