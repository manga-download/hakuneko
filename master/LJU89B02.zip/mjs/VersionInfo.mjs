export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '76306b',
        link: 'https://github.com/manga-download/hakuneko/commits/76306b1682ac6fab02ce7d3c7a400b77ee4709c7',
    }
};