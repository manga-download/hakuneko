export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e2cee2',
        link: 'https://github.com/manga-download/hakuneko/commits/e2cee264d444535cb713fb66809e0b1c4189d6e0',
    }
};