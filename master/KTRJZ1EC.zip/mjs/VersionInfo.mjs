export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '8691e3',
        link: 'https://github.com/manga-download/hakuneko/commits/8691e3453749c6a5d6372a71bad43e3ef92914e2',
    }
};