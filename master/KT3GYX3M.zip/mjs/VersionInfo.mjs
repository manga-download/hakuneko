export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '9ea0a1',
        link: 'https://github.com/manga-download/hakuneko/commits/9ea0a1033c93f4f5b830c14fe3453049d554b380',
    }
};