export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a113aa',
        link: 'https://github.com/manga-download/hakuneko/commits/a113aaec04e6b1213281376d11a032e6c502a6c8',
    }
};