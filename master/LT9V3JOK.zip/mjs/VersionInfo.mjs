export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4fb1b7',
        link: 'https://github.com/manga-download/hakuneko/commits/4fb1b74db264be96cf1882505aa97d9e570ad2f3',
    }
};