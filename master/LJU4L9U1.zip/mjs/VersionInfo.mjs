export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '22fd1e',
        link: 'https://github.com/manga-download/hakuneko/commits/22fd1e9d7ac778debc02eb628830bfc45bfd6d62',
    }
};