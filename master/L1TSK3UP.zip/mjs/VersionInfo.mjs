export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e422ff',
        link: 'https://github.com/manga-download/hakuneko/commits/e422fff0e543c367ec7f14b90415723ad2f2db69',
    }
};