export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '7fba72',
        link: 'https://github.com/manga-download/hakuneko/commits/7fba72cf737c71abad9bcfa094dceea1f126fa5d',
    }
};