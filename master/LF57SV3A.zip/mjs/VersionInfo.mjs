export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3a24c3',
        link: 'https://github.com/manga-download/hakuneko/commits/3a24c329acebe97442eba50eb4c894990bb3186c',
    }
};