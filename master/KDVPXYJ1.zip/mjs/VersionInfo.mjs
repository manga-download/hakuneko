export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '519631',
        link: 'https://github.com/manga-download/hakuneko/commits/519631791c9f6831c894f029ef5d2f58ca5b6922',
    }
};