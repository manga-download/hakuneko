export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '94a094',
        link: 'https://github.com/manga-download/hakuneko/commits/94a094bdca5df75b672cdbf64d057e86f2e44366',
    }
};