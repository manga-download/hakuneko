export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'bf7181',
        link: 'https://github.com/manga-download/hakuneko/commits/bf718196d752e5fefc8ad41de0dcbdf46260d49b',
    }
};