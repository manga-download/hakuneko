export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3c03dd',
        link: 'https://github.com/manga-download/hakuneko/commits/3c03dd9a25d3b08343271df3fd7611c29ea6771b',
    }
};