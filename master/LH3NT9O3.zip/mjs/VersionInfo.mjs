export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3b3230',
        link: 'https://github.com/manga-download/hakuneko/commits/3b3230f63638e3c2fed2b8a70ba6982b3ecffc0b',
    }
};