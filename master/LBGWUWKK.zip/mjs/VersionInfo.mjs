export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '2e169d',
        link: 'https://github.com/manga-download/hakuneko/commits/2e169d940672938a491b6609414e5fd51a47c15d',
    }
};