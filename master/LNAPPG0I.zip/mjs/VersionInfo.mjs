export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4e92a3',
        link: 'https://github.com/manga-download/hakuneko/commits/4e92a37dfd8ffe4c255865bd4cae73af0cceee66',
    }
};