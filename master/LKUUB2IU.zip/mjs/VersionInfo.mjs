export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e619d9',
        link: 'https://github.com/manga-download/hakuneko/commits/e619d92370f24c1ba4e2ac1aabb5aaddf99f047b',
    }
};