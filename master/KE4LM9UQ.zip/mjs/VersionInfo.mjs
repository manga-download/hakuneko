export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '8c7529',
        link: 'https://github.com/manga-download/hakuneko/commits/8c752954a74c8126755677501c602d2747ff0c8d',
    }
};