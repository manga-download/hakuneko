export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'c95803',
        link: 'https://github.com/manga-download/hakuneko/commits/c9580330cae3d61b7937b839a6c37e0a30dfb333',
    }
};