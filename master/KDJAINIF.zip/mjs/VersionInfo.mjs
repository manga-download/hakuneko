export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '6e02ee',
        link: 'https://github.com/manga-download/hakuneko/commits/6e02ee71f39e3427eefe0313ce01b145c4634dc2',
    }
};