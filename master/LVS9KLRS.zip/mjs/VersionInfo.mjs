export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '7f0658',
        link: 'https://github.com/manga-download/hakuneko/commits/7f0658f115d8e7ecad38725d653aedd69ac77c53',
    }
};