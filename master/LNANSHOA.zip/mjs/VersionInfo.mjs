export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f038a5',
        link: 'https://github.com/manga-download/hakuneko/commits/f038a5341f1eaa4cf2400629b9aad3cd69f1ad89',
    }
};