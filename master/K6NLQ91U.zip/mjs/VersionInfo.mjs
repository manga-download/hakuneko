export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f1d4b5',
        link: 'https://github.com/manga-download/hakuneko/commits/f1d4b5b29fa497d054777ba9377ffd780834f301',
    }
};