export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '540c33',
        link: 'https://github.com/manga-download/hakuneko/commits/540c33617e49584acff609f3322ea4e920c4d27b',
    }
};