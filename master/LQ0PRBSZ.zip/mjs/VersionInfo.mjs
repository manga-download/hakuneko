export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '8489cc',
        link: 'https://github.com/manga-download/hakuneko/commits/8489ccaadd5a18dc864ca333dfe26b46bac4da11',
    }
};