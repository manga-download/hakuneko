export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '72def9',
        link: 'https://github.com/manga-download/hakuneko/commits/72def907391e77d337d68f509fc7401a8106b55c',
    }
};