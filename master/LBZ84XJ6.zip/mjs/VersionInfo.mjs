export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5da2de',
        link: 'https://github.com/manga-download/hakuneko/commits/5da2defdcdb160aecff1c64f296ce41899d62202',
    }
};