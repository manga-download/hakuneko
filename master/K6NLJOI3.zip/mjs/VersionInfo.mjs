export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a46be8',
        link: 'https://github.com/manga-download/hakuneko/commits/a46be82c8c177a9114ab11bfa07aa1fe406b6d87',
    }
};