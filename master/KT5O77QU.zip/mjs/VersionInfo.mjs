export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a68b56',
        link: 'https://github.com/manga-download/hakuneko/commits/a68b568b06c5a276a451a93b5683e2939d3351d2',
    }
};