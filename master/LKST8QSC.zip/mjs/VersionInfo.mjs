export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5e8ca7',
        link: 'https://github.com/manga-download/hakuneko/commits/5e8ca7caebd36b2d98b3f461df718d32b597a9a0',
    }
};