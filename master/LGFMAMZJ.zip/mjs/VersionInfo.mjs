export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '9614c7',
        link: 'https://github.com/manga-download/hakuneko/commits/9614c7721d3ea5a6b2fd6f99c748a4dbca71eed0',
    }
};