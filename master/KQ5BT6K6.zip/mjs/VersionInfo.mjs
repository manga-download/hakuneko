export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f7e357',
        link: 'https://github.com/manga-download/hakuneko/commits/f7e3576a9944dcd9b86208583057bb7c56bf422b',
    }
};