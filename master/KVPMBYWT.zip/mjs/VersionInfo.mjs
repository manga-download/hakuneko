export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '74ca1d',
        link: 'https://github.com/manga-download/hakuneko/commits/74ca1d36eb0c7fb772caf999209786ff569463d9',
    }
};