export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '9d3f6a',
        link: 'https://github.com/manga-download/hakuneko/commits/9d3f6a9df1cec33e862d090c4fda257b2bef95aa',
    }
};