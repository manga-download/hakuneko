export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '04aa09',
        link: 'https://github.com/manga-download/hakuneko/commits/04aa092192763fda53bf70107c9839e5b21cbcb6',
    }
};