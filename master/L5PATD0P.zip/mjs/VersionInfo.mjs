export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '83d65a',
        link: 'https://github.com/manga-download/hakuneko/commits/83d65ad3786739914971739bf338ae4f94b98ed4',
    }
};