export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '08957d',
        link: 'https://github.com/manga-download/hakuneko/commits/08957dcde9ff0903bf9c6210a7cb0c3b80c4dff4',
    }
};