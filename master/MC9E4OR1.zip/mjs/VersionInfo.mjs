export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '59a21d',
        link: 'https://github.com/manga-download/hakuneko/commits/59a21d568f4c294ef27f4de0840b6ed9c58b4ee2',
    }
};