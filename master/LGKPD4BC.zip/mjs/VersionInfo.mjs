export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '0d8676',
        link: 'https://github.com/manga-download/hakuneko/commits/0d867681cdb99ac5eac20d9b6765d69b0ff92156',
    }
};