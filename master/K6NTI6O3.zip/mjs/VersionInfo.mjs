export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e86821',
        link: 'https://github.com/manga-download/hakuneko/commits/e86821d1ce9cc3d9671ca0ea04f1540c94840fc9',
    }
};