export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'c64159',
        link: 'https://github.com/manga-download/hakuneko/commits/c64159bb09d7d3c8ef0a1dcc3b5dd7b7b01840e9',
    }
};