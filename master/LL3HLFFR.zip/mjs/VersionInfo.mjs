export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '0a3781',
        link: 'https://github.com/manga-download/hakuneko/commits/0a3781828cc31170323119602777972dd04442e2',
    }
};