export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e84a51',
        link: 'https://github.com/manga-download/hakuneko/commits/e84a51ff33c34e83125d87bd178a835832e217c7',
    }
};