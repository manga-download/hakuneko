export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '569fe0',
        link: 'https://github.com/manga-download/hakuneko/commits/569fe098efdd39125bd6792897be609091610524',
    }
};