export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'c87018',
        link: 'https://github.com/manga-download/hakuneko/commits/c870186a3b72eef0f8daad21c207e2acbbb2167e',
    }
};