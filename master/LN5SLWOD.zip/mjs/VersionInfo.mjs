export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '007ba9',
        link: 'https://github.com/manga-download/hakuneko/commits/007ba99a3230fbcffc50e3657b887f56d6c67a18',
    }
};