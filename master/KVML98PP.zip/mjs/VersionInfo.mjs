export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4ce114',
        link: 'https://github.com/manga-download/hakuneko/commits/4ce1149ac5f17868c5ca620a7b8a8f83c49e1066',
    }
};