export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e334bc',
        link: 'https://github.com/manga-download/hakuneko/commits/e334bc3a9b3871c10b173a37ddb79215080a919f',
    }
};