export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'c71958',
        link: 'https://github.com/manga-download/hakuneko/commits/c719582a36a3374cb53a7bf3eb0fa1304af64164',
    }
};