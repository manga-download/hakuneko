export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5d39b5',
        link: 'https://github.com/manga-download/hakuneko/commits/5d39b5c6089b1346e9e059fc2d014f678b8c4b0b',
    }
};