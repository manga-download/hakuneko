export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '6b029c',
        link: 'https://github.com/manga-download/hakuneko/commits/6b029cabe9b0aac704757a41fd597dd0709dc705',
    }
};