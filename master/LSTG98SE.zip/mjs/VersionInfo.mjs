export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1be496',
        link: 'https://github.com/manga-download/hakuneko/commits/1be496912cc0f219b3eab97dcd347fb2a6f63691',
    }
};