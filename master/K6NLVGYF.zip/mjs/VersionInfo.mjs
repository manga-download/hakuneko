export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '7827ab',
        link: 'https://github.com/manga-download/hakuneko/commits/7827ab1551d40b5f18fdf415c9ff37f5de231fe8',
    }
};