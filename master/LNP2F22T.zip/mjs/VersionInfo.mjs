export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b610b0',
        link: 'https://github.com/manga-download/hakuneko/commits/b610b01bf7456005f800cefe607f763d356a4876',
    }
};