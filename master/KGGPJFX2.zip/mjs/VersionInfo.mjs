export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5af453',
        link: 'https://github.com/manga-download/hakuneko/commits/5af453a2e586faa7edf1f14d582c147e0268f272',
    }
};