export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '8859e3',
        link: 'https://github.com/manga-download/hakuneko/commits/8859e33ea08ec36d8f7ae68493509f9c4933b6ec',
    }
};