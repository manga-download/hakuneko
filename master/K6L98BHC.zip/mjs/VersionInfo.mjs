export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '705d66',
        link: 'https://github.com/manga-download/hakuneko/commits/705d6683e7aed6ac3d666cf38082ff4fb76d14a5',
    }
};