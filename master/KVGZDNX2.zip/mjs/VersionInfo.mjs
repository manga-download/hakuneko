export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '607159',
        link: 'https://github.com/manga-download/hakuneko/commits/60715994e581fca3a74acabcc3eac6debd5616d1',
    }
};