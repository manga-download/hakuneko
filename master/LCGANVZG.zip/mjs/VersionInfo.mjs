export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'accce9',
        link: 'https://github.com/manga-download/hakuneko/commits/accce9d702c4d00e22c119c37c19278a91a8d9cd',
    }
};