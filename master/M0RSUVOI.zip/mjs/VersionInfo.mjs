export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a88351',
        link: 'https://github.com/manga-download/hakuneko/commits/a88351d3f81bc3833f10c0e60bc4b6cb52b9e89c',
    }
};