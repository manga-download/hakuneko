export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e6ec2e',
        link: 'https://github.com/manga-download/hakuneko/commits/e6ec2e2494da7c272f1526ee7695085530dddac1',
    }
};