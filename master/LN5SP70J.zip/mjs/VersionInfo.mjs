export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3a4629',
        link: 'https://github.com/manga-download/hakuneko/commits/3a4629b7ee26930e3d78f56fa80be55b71ce4afe',
    }
};