export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b60934',
        link: 'https://github.com/manga-download/hakuneko/commits/b609349a8f28e154db9e4fb9aac0e8878880a163',
    }
};