export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '9f87bf',
        link: 'https://github.com/manga-download/hakuneko/commits/9f87bf0e6e9ab5c6e2c2801e3c9eae553f07d48d',
    }
};