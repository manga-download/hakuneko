export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '248561',
        link: 'https://github.com/manga-download/hakuneko/commits/248561af82e11d65de0a51d1aff1146cd1247485',
    }
};