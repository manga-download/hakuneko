export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '75a25b',
        link: 'https://github.com/manga-download/hakuneko/commits/75a25bf0975e136dcc742adaa987c4cbe365ad0d',
    }
};