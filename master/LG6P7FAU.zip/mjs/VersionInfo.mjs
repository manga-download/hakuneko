export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'e7ed0b',
        link: 'https://github.com/manga-download/hakuneko/commits/e7ed0b1e4656ad6829f23708a0206228f67adc0f',
    }
};