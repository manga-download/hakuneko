export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f1db6e',
        link: 'https://github.com/manga-download/hakuneko/commits/f1db6ed29d22d8ca4e6dbebb1732f55f335aa57b',
    }
};