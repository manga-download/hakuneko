export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '173fdd',
        link: 'https://github.com/manga-download/hakuneko/commits/173fddfe8d42d4137d4fef467741924de0fb400e',
    }
};