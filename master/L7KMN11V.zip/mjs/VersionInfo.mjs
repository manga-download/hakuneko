export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '55a2e1',
        link: 'https://github.com/manga-download/hakuneko/commits/55a2e1719f28298460e44853a98b834b0499309c',
    }
};