export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b67ab0',
        link: 'https://github.com/manga-download/hakuneko/commits/b67ab095f38581d3a6826c113e67d4e74cb41fdb',
    }
};