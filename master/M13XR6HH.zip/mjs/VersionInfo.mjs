export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '0bf6af',
        link: 'https://github.com/manga-download/hakuneko/commits/0bf6af0f2403ce20a4fa6e1cfaf05b727bd98bc3',
    }
};