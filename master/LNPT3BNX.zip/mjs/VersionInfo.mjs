export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'f01c3e',
        link: 'https://github.com/manga-download/hakuneko/commits/f01c3ef34798407f93dbc19eb98011a1606848ba',
    }
};