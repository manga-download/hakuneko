export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '0e6f42',
        link: 'https://github.com/manga-download/hakuneko/commits/0e6f42d3f93e221ea16739944aa84248ed384f80',
    }
};