export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'bd682d',
        link: 'https://github.com/manga-download/hakuneko/commits/bd682d864a4b2a6a6f2a7b874b789485ad4acd79',
    }
};