export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '91c181',
        link: 'https://github.com/manga-download/hakuneko/commits/91c18145822a2aff19bf8fb8fedc6cd7ab366c8e',
    }
};