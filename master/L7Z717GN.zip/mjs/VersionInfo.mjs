export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '105b9a',
        link: 'https://github.com/manga-download/hakuneko/commits/105b9a6887f29c4c2678e5350d4d86b8561c17ef',
    }
};