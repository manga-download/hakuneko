export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '7b469e',
        link: 'https://github.com/manga-download/hakuneko/commits/7b469e5534d39893d43fbc125c27cda595590ad4',
    }
};