export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'aa8c70',
        link: 'https://github.com/manga-download/hakuneko/commits/aa8c7066ed9d23f2bbe8943d661fc5a757bf9e81',
    }
};