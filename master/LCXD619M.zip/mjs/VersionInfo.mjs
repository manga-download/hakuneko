export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '7e6d30',
        link: 'https://github.com/manga-download/hakuneko/commits/7e6d30f7bc28f7e84836514ddb54e8c97790dece',
    }
};