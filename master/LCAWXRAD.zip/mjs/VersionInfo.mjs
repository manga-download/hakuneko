export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'd6ede5',
        link: 'https://github.com/manga-download/hakuneko/commits/d6ede5da02facb0dab4d19bb69b3e4e36c90d5ee',
    }
};