export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b87827',
        link: 'https://github.com/manga-download/hakuneko/commits/b878272519f44f9409e525919f2b55865f6cfc79',
    }
};