export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1952cb',
        link: 'https://github.com/manga-download/hakuneko/commits/1952cb4e7a57197abda689892cb977e350473cfb',
    }
};