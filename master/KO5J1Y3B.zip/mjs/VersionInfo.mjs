export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ef26a5',
        link: 'https://github.com/manga-download/hakuneko/commits/ef26a5ef13dcdba26d6df78fca41f28672687d2b',
    }
};