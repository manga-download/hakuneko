export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '99d6ec',
        link: 'https://github.com/manga-download/hakuneko/commits/99d6ecdb32c87b11f49d6b94069740935932cbc3',
    }
};