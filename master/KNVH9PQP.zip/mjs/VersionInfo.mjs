export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'fedef6',
        link: 'https://github.com/manga-download/hakuneko/commits/fedef67120a587ce11f189eb9358746a22a5eb46',
    }
};