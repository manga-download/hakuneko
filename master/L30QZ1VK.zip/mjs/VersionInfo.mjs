export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '94cc40',
        link: 'https://github.com/manga-download/hakuneko/commits/94cc40b225ea81f4b08d6ef2ce6adbf78c8494be',
    }
};