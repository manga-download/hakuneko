export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5aedba',
        link: 'https://github.com/manga-download/hakuneko/commits/5aedba5fba14ada5ba51f98976c63d7a55c411f7',
    }
};