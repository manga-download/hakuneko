export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '7fc984',
        link: 'https://github.com/manga-download/hakuneko/commits/7fc984e2f6bc740f1945e018319afc7d6dca8b88',
    }
};