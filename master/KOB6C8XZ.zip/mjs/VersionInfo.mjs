export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '815f6c',
        link: 'https://github.com/manga-download/hakuneko/commits/815f6cb702e100aaec3e8b6b70a6bce479fb4ac7',
    }
};