export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '05fe2b',
        link: 'https://github.com/manga-download/hakuneko/commits/05fe2b9e2673eea05bdbbb75a9b35286de6c02f4',
    }
};