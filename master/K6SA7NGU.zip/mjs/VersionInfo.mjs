export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3db290',
        link: 'https://github.com/manga-download/hakuneko/commits/3db290dc44fc05c721514d199cc25a0e27606bbd',
    }
};