export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'fa1af6',
        link: 'https://github.com/manga-download/hakuneko/commits/fa1af62c6b3d68dc808957c12d037db809bb6fbf',
    }
};