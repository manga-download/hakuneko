export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '855f06',
        link: 'https://github.com/manga-download/hakuneko/commits/855f06df851bd91da4badd26ceb86b0e7b88186f',
    }
};