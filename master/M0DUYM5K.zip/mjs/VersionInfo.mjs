export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '4a58ff',
        link: 'https://github.com/manga-download/hakuneko/commits/4a58ff173a763681c76b275070c1f3e1e841f427',
    }
};