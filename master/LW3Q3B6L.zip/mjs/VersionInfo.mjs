export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ff293c',
        link: 'https://github.com/manga-download/hakuneko/commits/ff293c0fdb2bc023de9c3501e1515a90021a9b5a',
    }
};