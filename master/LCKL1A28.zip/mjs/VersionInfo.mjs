export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '8663dc',
        link: 'https://github.com/manga-download/hakuneko/commits/8663dcf09294874513bce7c1f8a043b9a2361149',
    }
};