export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'fb72cc',
        link: 'https://github.com/manga-download/hakuneko/commits/fb72cc549d5b92458e30b252ffff1110c16e4037',
    }
};