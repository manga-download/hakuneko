export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '04c77a',
        link: 'https://github.com/manga-download/hakuneko/commits/04c77a025d373d860b5d8d36014b19f5c02ae42a',
    }
};