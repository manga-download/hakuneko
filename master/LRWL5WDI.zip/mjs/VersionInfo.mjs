export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '6d1360',
        link: 'https://github.com/manga-download/hakuneko/commits/6d13602ae1d4b8ef33c0f03e0db1fb4c58ecf9aa',
    }
};