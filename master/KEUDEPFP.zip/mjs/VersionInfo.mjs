export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'b8eaea',
        link: 'https://github.com/manga-download/hakuneko/commits/b8eaea311aaacec56cce8d94555dabee91433acd',
    }
};