export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1833fc',
        link: 'https://github.com/manga-download/hakuneko/commits/1833fc6aa8278d13f2f149ad23d4be88e79e4861',
    }
};