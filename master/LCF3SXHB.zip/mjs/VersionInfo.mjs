export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1a9219',
        link: 'https://github.com/manga-download/hakuneko/commits/1a921971adf2712194dc692442177c203c52064e',
    }
};