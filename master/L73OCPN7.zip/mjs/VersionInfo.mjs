export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3de05f',
        link: 'https://github.com/manga-download/hakuneko/commits/3de05f464ec1f0812bbcb0dfc53878dcdfd9ec1f',
    }
};