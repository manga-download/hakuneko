export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'feb527',
        link: 'https://github.com/manga-download/hakuneko/commits/feb5278cee137344f2ad2c5bd35baaf9d23d5432',
    }
};