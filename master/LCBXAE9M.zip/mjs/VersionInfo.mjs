export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '5c35da',
        link: 'https://github.com/manga-download/hakuneko/commits/5c35da7b25648b34cfca0228c42ba6ff56f61b95',
    }
};