export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '95bfdc',
        link: 'https://github.com/manga-download/hakuneko/commits/95bfdc2edb845b19252496d7653b934469a1b586',
    }
};