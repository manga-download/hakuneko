export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '562710',
        link: 'https://github.com/manga-download/hakuneko/commits/562710c521d1e3e9a87be0ad680d8143c2e9f7bf',
    }
};