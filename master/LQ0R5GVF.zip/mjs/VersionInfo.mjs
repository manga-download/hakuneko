export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '74cb06',
        link: 'https://github.com/manga-download/hakuneko/commits/74cb06d816dbfcea0615770e1e43aaeddc3b8617',
    }
};