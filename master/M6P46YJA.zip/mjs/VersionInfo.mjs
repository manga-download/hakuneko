export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'ff1cc1',
        link: 'https://github.com/manga-download/hakuneko/commits/ff1cc175f537d2e01539d9326e3f768849818588',
    }
};