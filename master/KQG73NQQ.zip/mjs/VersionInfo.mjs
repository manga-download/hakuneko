export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '8ff324',
        link: 'https://github.com/manga-download/hakuneko/commits/8ff3247d7c17c3285acff0968c90721e2fe25ca3',
    }
};