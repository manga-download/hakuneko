export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '894a31',
        link: 'https://github.com/manga-download/hakuneko/commits/894a31f38ce08fdf47e6a6c981aa77fa5bfccff6',
    }
};