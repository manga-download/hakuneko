export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'bef016',
        link: 'https://github.com/manga-download/hakuneko/commits/bef01611022ea8ac6bbcd3be28fd292e332f5bdc',
    }
};