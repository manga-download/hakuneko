export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '1acbfb',
        link: 'https://github.com/manga-download/hakuneko/commits/1acbfb61e44cf0e547549fd337d329d2bbcae137',
    }
};