export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '3abae1',
        link: 'https://github.com/manga-download/hakuneko/commits/3abae1debd55c68835e717b9c5704fedbdafc812',
    }
};