export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: 'a48270',
        link: 'https://github.com/manga-download/hakuneko/commits/a48270b6156fb790f387f3344c8da669c1fc198a',
    }
};