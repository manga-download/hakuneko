export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '2f6063',
        link: 'https://github.com/manga-download/hakuneko/commits/2f606386b912b0aeb53a9e3a2197ce52523a2ebd',
    }
};