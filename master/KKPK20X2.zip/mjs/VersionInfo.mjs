export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '23c2e9',
        link: 'https://github.com/manga-download/hakuneko/commits/23c2e9fb5975b76af6786c3cff86e6aaa5e39343',
    }
};