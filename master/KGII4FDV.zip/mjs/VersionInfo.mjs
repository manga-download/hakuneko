export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '454dc9',
        link: 'https://github.com/manga-download/hakuneko/commits/454dc9de4c6c77dd0a899c2e4d271548b386ea34',
    }
};