export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '222beb',
        link: 'https://github.com/manga-download/hakuneko/commits/222bebad96d5efffe0bb2261819c25532adcad19',
    }
};