export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '13721e',
        link: 'https://github.com/manga-download/hakuneko/commits/13721e5b0ed00f35749ec46d289913f140b3641a',
    }
};