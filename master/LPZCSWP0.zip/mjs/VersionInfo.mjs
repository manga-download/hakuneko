export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '23044e',
        link: 'https://github.com/manga-download/hakuneko/commits/23044e696cde9e2d36b453dc0b3495320eadbd98',
    }
};