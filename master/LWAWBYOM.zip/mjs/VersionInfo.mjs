export default {
    branch: {
        label: 'master',
        link: 'https://github.com/manga-download/hakuneko/commits/master',
    },
    revision: {
        label: '471944',
        link: 'https://github.com/manga-download/hakuneko/commits/471944bebfef116d18b4b30c0f28d6d1c84803af',
    }
};