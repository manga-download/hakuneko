export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '9436d8',
        link: 'https://github.com/manga-download/hakuneko/commits/9436d83da23bbc5a557077393d6f93c495b92b5c',
    }
};