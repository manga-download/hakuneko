export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '8f3184',
        link: 'https://github.com/manga-download/hakuneko/commits/8f3184563054865a6f87242d045f76ee643f164e',
    }
};