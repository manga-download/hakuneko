export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '44467e',
        link: 'https://github.com/manga-download/hakuneko/commits/44467e41464726259a7f0239dab3cb5f9dc5ca8c',
    }
};