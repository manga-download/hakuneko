export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '81234d',
        link: 'https://github.com/manga-download/hakuneko/commits/81234da2ba9c614f4e1bc93b6b20c8c69757373a',
    }
};