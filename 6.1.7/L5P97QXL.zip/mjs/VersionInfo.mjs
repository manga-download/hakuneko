export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '7ed275',
        link: 'https://github.com/manga-download/hakuneko/commits/7ed2753a697f9341432e4714e83b49c057d9d84a',
    }
};