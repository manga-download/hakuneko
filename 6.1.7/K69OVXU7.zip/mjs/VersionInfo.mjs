export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '86dbf8',
        link: 'https://github.com/manga-download/hakuneko/commits/86dbf890d4cd964ba47120ee5b1748514072f7c7',
    }
};