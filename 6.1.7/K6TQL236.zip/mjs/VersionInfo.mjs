export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '0fe9c0',
        link: 'https://github.com/manga-download/hakuneko/commits/0fe9c0128d6a6000d8229c66e97c433905e7eb4a',
    }
};