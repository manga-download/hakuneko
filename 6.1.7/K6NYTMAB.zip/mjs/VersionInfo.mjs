export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: 'd52927',
        link: 'https://github.com/manga-download/hakuneko/commits/d529275d2c6a9dc0df1d30fcd0ea18360b6135e0',
    }
};