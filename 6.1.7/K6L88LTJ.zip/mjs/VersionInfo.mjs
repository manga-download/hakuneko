export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '2f20bd',
        link: 'https://github.com/manga-download/hakuneko/commits/2f20bd7aa256e3a46bf198d70d1597e17847c9c9',
    }
};