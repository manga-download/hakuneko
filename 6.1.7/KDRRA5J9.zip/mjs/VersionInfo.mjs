export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '4544fa',
        link: 'https://github.com/manga-download/hakuneko/commits/4544fa500bf2107c1f68c42b0c25adf05b19af3e',
    }
};