export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '80ac18',
        link: 'https://github.com/manga-download/hakuneko/commits/80ac187671bf9d132c944859a90c23e01fc6bd3c',
    }
};