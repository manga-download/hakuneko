export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: 'b526fd',
        link: 'https://github.com/manga-download/hakuneko/commits/b526fdc24ed393ec222d5209b0d16cd85e4cc443',
    }
};