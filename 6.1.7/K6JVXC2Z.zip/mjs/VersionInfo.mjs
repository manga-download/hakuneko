export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '482b63',
        link: 'https://github.com/manga-download/hakuneko/commits/482b63086d024b5a9e43a232f6c62f82fed804e3',
    }
};