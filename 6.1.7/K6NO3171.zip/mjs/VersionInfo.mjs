export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: 'a21840',
        link: 'https://github.com/manga-download/hakuneko/commits/a21840fbe9ee03dd18c75b0b212e643ffce054b6',
    }
};