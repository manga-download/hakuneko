export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: 'a8e80e',
        link: 'https://github.com/manga-download/hakuneko/commits/a8e80e983344f758cc635d69268fca3187ad7e48',
    }
};