export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '351716',
        link: 'https://github.com/manga-download/hakuneko/commits/351716084a89f30944eb3e392dec81da88143ba5',
    }
};