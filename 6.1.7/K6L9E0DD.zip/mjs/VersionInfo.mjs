export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '081ece',
        link: 'https://github.com/manga-download/hakuneko/commits/081ecef2db96ce1ae185e0f872caa61727be2f16',
    }
};