export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '1a2ca3',
        link: 'https://github.com/manga-download/hakuneko/commits/1a2ca3ad3d32cb6f249e82876a066b6a6344c9cd',
    }
};