export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '554b0c',
        link: 'https://github.com/manga-download/hakuneko/commits/554b0cfcd34535376a0c9c2b2a1dd5d3c7963e30',
    }
};