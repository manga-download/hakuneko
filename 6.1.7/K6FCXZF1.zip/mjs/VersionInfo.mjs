export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: 'b940ad',
        link: 'https://github.com/manga-download/hakuneko/commits/b940adc18ddc8e179034be9a837ea69e766fb4ed',
    }
};