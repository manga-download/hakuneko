export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '861007',
        link: 'https://github.com/manga-download/hakuneko/commits/861007f2e09ef86f2e5ff1b07d875794e77b920b',
    }
};