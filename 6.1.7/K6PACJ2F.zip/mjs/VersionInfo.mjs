export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '3913b6',
        link: 'https://github.com/manga-download/hakuneko/commits/3913b69a25fd3de8287310d8d5a70e57fbad6783',
    }
};