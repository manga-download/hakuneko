export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '0d8907',
        link: 'https://github.com/manga-download/hakuneko/commits/0d8907a3d21e35dc224d2fcf4066dae1aaa934ba',
    }
};