export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '997c29',
        link: 'https://github.com/manga-download/hakuneko/commits/997c2965cf85402ea928757f77c19b1e71321b6b',
    }
};