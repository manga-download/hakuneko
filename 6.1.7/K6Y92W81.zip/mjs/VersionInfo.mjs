export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '8ebc34',
        link: 'https://github.com/manga-download/hakuneko/commits/8ebc349ea3ee289aa71d94a779fc980fe8e04d9d',
    }
};