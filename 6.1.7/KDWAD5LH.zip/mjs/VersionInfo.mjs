export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '925098',
        link: 'https://github.com/manga-download/hakuneko/commits/92509813d9532e571d608a7c4797c7cd06420395',
    }
};