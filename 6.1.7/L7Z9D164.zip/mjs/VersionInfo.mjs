export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: 'a8da6a',
        link: 'https://github.com/manga-download/hakuneko/commits/a8da6a555e247e09e539d2d1ba05cb0fd72e9a04',
    }
};