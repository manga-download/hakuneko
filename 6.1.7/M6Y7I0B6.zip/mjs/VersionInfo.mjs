export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '52850a',
        link: 'https://github.com/manga-download/hakuneko/commits/52850a81e5e50fec95e7490c63f8afacb209dddd',
    }
};