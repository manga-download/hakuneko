export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: 'b96fdb',
        link: 'https://github.com/manga-download/hakuneko/commits/b96fdbba5a9bd20d25814cfccabdae2aa431c593',
    }
};