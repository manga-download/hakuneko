export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: 'da8633',
        link: 'https://github.com/manga-download/hakuneko/commits/da8633fd2c1595a1f36fc48b44343a3887ab4612',
    }
};