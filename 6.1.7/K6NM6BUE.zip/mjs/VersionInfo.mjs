export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '2e51a7',
        link: 'https://github.com/manga-download/hakuneko/commits/2e51a7a3865a75c88045da3ebacf321a2cc15fbb',
    }
};