export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '8f28f9',
        link: 'https://github.com/manga-download/hakuneko/commits/8f28f9c8a5ec6bdf40c4348ec2842511b9039961',
    }
};