export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: 'ef0a7e',
        link: 'https://github.com/manga-download/hakuneko/commits/ef0a7e3c51deab20e7ef30e52a799745f248e55c',
    }
};