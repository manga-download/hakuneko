export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: 'b28493',
        link: 'https://github.com/manga-download/hakuneko/commits/b284938b3c3069aaaca8de40f7a0a177cfd703f3',
    }
};