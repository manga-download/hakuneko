export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '633faf',
        link: 'https://github.com/manga-download/hakuneko/commits/633faf7aa8bc5893a7748b595f8101f6a7ac64b9',
    }
};