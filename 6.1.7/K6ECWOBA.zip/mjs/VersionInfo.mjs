export default {
    branch: {
        label: '6.1.7',
        link: 'https://github.com/manga-download/hakuneko/commits/6.1.7',
    },
    revision: {
        label: '76e9cf',
        link: 'https://github.com/manga-download/hakuneko/commits/76e9cfea24fa2617b332fc6888b3ffb6a9e2f1f2',
    }
};